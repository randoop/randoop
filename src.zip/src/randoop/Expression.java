package randoop;

/**
 * A randoop Expression is much like a regular Java expression: it denotes some
 * computation that produces a value. Typically, the expression is over a
 * collection of values. For example, the expression "o1.equals(o2)" is an
 * expression over the values o1 and o2 and produces a boolean value.
 * 
 * A randoop expression should evaluate to null, a primitive value, or a String,
 * or throw an exception. It should not modify the state of the values, but we
 * do not check for this.
 * 
 */
public interface Expression {

	int getArity();

	Object evaluate(Object... values);
}
