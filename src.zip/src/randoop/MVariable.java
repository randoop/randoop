package randoop;

/**
 * A variable that is part of a mutable sequence.
 */
public class MVariable {
	
	public final MSequence owner;
	private final String name;

	public MVariable(MSequence owner, String name) {
		if (owner == null) throw new IllegalArgumentException();
		if (name == null) throw new IllegalArgumentException();
		
		this.owner = owner;
		this.name = name;
	}

	public MStatementCall getCreatingStatementWithInputs() {
		return owner.getStatementWithInputs(this);
	}

	public Class<?> getType() {
		return owner.getStatementWithInputs(this).statement.getOutputType();
	}

	public int getIndex() {
		return owner.getIndex(this);
	}
	
	public String getName() {
		return name;
	}
	
	@Override
	public String toString() {
		return getName();
	}
		
}
