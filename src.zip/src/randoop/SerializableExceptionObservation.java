package randoop;

import java.io.ObjectStreamException;
import java.io.Serializable;

import randoop.util.SerializationHelper;

public class SerializableExceptionObservation implements Serializable {

	private String exceptionClass;

	public SerializableExceptionObservation(Class<? extends Throwable> exceptionClass) {
		this.exceptionClass = SerializationHelper.serializeClass(exceptionClass);
	}
	
	private Object writeReplace() throws ObjectStreamException {
		return SerializationHelper.deserializeClass(exceptionClass);
	}

}
