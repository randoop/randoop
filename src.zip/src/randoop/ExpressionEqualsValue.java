package randoop;

import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.List;

import randoop.util.PrimitiveTypes;

/**
 * An observation recording the value of an expression evaluated
 * to during execution. In particular, this observation represents
 * the following assertion in terms of its state variables:
 * 
 *     expression(vars) == value
 *     
 */
public class ExpressionEqualsValue implements Observation, Serializable {

	// The expression whose runtime value this observation records.
	public Class<? extends Expression> expression;

	// The variables over which the expression applies.
	public List<Variable> vars;

	// The runtime value of the expression.
	public Object value;

	public ExpressionEqualsValue(Class<? extends Expression> expression,
			List<Variable> vars, Object value) {
		if (value == null)
			throw new IllegalArgumentException("value cannot be null.");
		if (expression == null)
			throw new IllegalArgumentException("expression cannot be null.");
		if (value != null && !isPrimitiveOrString(value))
			throw new IllegalArgumentException("value is not a primitive or string : " +
					value.getClass());
		this.expression = expression;
		this.value = value;
	}
	

	private Object writeReplace() throws ObjectStreamException {
		return new SerializableExpressionObservation(expression, vars, value);
	}

	public String toCodeStringPreStatement() {
		return "";
	}

	public String toCodeStringPostStatement() {
		StringBuilder expressionString = new StringBuilder();
		expressionString.append("assertEquals(");
		expressionString.append(PrimitiveTypes.toCodeString(value));
		expressionString.append(",");
		Class<?> valueClass = PrimitiveTypes.primitiveType(value.getClass());
		expressionString.append(castTo(valueClass));
		expressionString.append("(new ");
		expressionString.append(expression.getPackage().getName());
		expressionString.append(".");
		expressionString.append(expression.getName());
		expressionString.append("(");
		for (int i = 0 ; i < vars.size() ; i++) {
			if (i > 0)
				expressionString.append(",");
			expressionString.append(vars.get(i).toString());
		}
		expressionString.append(")));");
		return expressionString.toString();
	}

	/*
	 * We may need 2 casts here, to cover all 4 cases (note: we don't know how
	 * the variable will be declared in source).
	 * 
	 * Example assertEquals((float) 10.0, (float)(Float)var22);
	 * 
	 * 1) Object compared to primitive: if var22 is Object
	 * 2) primitive compared to primitive: if var22 is float
	 * 3) boxed primitive compared to primitive: if var22 is Float
	 * 3) Object or String compared to String: if var22 is assertEquals("foo",
	 * (java.lang.String)var22);
	 */
	private String castTo(Class<?> valueClass) {
		if (valueClass.equals(String.class))
			return "(" + valueClass.getCanonicalName() + ")";
		else
			return "(" + valueClass.getCanonicalName() + ")(" +
			PrimitiveTypes.boxedType(valueClass).getCanonicalName() + ")";
	}

	public static boolean isPrimitiveOrString(Object o) {
		return PrimitiveTypes.isBoxedPrimitiveTypeOrString(o.getClass())
		|| String.class.equals(o.getClass());
	}
}
