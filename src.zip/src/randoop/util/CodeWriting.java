package randoop.util;

import utilMDE.UtilMDE;

public class CodeWriting {

    public static String getCompilableClassnameString(String typeString) {
        String retval = typeString;
        if (retval.startsWith("[")) {
            // TODO the last replace is ugly. There should be a method that does it.
            retval = UtilMDE.classnameFromJvm(retval);
        }
        retval = retval.replace('$', '.');
        return retval;
    }
}
