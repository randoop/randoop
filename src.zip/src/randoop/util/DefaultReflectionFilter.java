package randoop.util;

import java.lang.reflect.*;
import java.util.Arrays;
import java.util.regex.Pattern;

/**
 * Returns true for anything declared public, with two exceptions: (1) returns
 * false for methods declared by Object (i.e. hashCode, wait, notifyAll, etc).
 * These are typically useless for most input generation purposes. (2) Returns
 * false for any method with name "hashCode" (these are also typically useless
 * for input generation, and result in non-repro behavior).
 *
 */
public class DefaultReflectionFilter implements ReflectionFilter {

    private Pattern omitmethods = null;

    private static final boolean VERBOSE= false;

    /** omitmethods can be null (which means "omit no methods") */
    public DefaultReflectionFilter(Pattern omitmethods) {
        super();
        this.omitmethods = omitmethods;
    }
    
    public boolean canUse(Class<?> c) {
        return Modifier.isPublic(c.getModifiers());
    }

    public boolean canUse(Method m) {
        if (matchesOmitMethodPattern(m.toString())) {
            if (VERBOSE){
                System.out.println("Will not use: " + m.toString());
                System.out.println("  reason: matches regexp specified in -omitmethods option.");
            }
            return false;
        }

        if (m.isBridge()){
            if (VERBOSE){
                System.out.println("Will not use: " + m.toString());
                System.out.println("  reason: it's a bridge method");
            }
            return false;
        }

        if (m.isSynthetic()){
            if (VERBOSE){
                System.out.println("Will not use: " + m.toString());
                System.out.println("  reason: it's a synthetic method");
            }
            return false;
        }

        if (!Modifier.isPublic(m.getModifiers()))
        	return false;
//        if (Modifier.isPrivate(m.getModifiers()) || Modifier.isProtected(m.getModifiers()))
//            return false;

        //TODO we could enable some methods from Object, like getClass
        if (m.getDeclaringClass().equals(java.lang.Object.class))
            return false;//handled here to avoid printing reasons
        
        if (m.getDeclaringClass().equals(java.lang.Thread.class))
            return false;//handled here to avoid printing reasons
        
        String reason = doNotUseSpecialCase(m);
        if (reason != null) {
            if (VERBOSE){
                System.out.println("Will not use: " + m.toString());
                System.out.println("  reason: " + reason);
            }
            return false;
        }
        
        return true;
    }

    private String doNotUseSpecialCase(Method m) {

        // Special case 1: 
        // We're skipping compareTo method in enums - you can call it only with the same type as receiver 
        // but the signature does not tell you that 
        if (m.getDeclaringClass().getCanonicalName().equals("java.lang.Enum")
            && m.getName().equals("compareTo")
            && m.getParameterTypes().length == 1
            && m.getParameterTypes()[0].equals(Enum.class))
            return "We're skipping compareTo method in enums";
        
        // Sepcial case 2: 
        if (m.getName().equals("randomUUID"))
            return "We're skipping this to get reproducibility when running java.util tests.";
        
        // Special case 2: 
        //hashCode is bad in general but String.hashCode is fair game
        if (m.getName().equals("hashCode") && ! m.getDeclaringClass().equals(String.class))
            return "hashCode";

        // Special case 3: (just clumps together a bunch of hashCodes, so skip it)
        if (m.getName().equals("deepHashCode") && m.getDeclaringClass().equals(Arrays.class))
            return "deepHashCode";

        // Special case 4: (differs too much between JDK installations) 
        if (m.getName().equals("getAvailableLocales"))
            return "getAvailableLocales";
        return null;
    }

    public boolean canUse(Constructor<?> c) {

        if (matchesOmitMethodPattern(c.getName())) {
            System.out.println("Will not use: " + c.toString());
            return false;
        }

        //synthetic constructors are OK
        
        if (Modifier.isAbstract(c.getDeclaringClass().getModifiers()))
            return false;
        if (Modifier.isPublic(c.getModifiers()))
            return true;
        return false;
    }

    private boolean matchesOmitMethodPattern(String name) {
        return omitmethods != null && omitmethods.matcher(name).find();
    }

}
