package randoop.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.util.ArrayList;

import utilMDE.UtilMDE;

/**
 * A collection of static methods that randoop uses
 * to serialize and deserialize its data structures.
 * Mainly concerns (de)serialization of reflection
 * objects like methods, constructors and classes.
 *
 */
public final class SerializationHelper {

    private SerializationHelper(){
        //no instances
    }

    public static void writeSerialized(String fileName, Object o) {
        writeSerialized(new File(fileName), o);
    }
    
    public static void writeSerialized(File outFile, Object o) {
        ObjectOutputStream out = null;
        try {
            out = new ObjectOutputStream(new FileOutputStream(outFile));

            out.writeObject(o);

        } catch (Exception e) {
            Log.out.println("When trying to create a PrintWriter for file "
                    + outFile + ", exception thrown: " + e);
            e.printStackTrace();
            throw new Error(e);
        }

    }

    public static Object readSerialized(String fileName) {
        return readSerialized(new File(fileName));
    }
    
    public static Object readSerialized(File inFile) {
        Object ret = null;
        try {
            FileInputStream fs = new FileInputStream(inFile);
            ObjectInputStream in = null;
            in = new ObjectInputStream(fs);
            ret = in.readObject();
            in.close();
            fs.close();
            return ret;
        } catch (Exception e) {
            Log.out.println("When trying to read serialized file " + inFile
                    + ", exception thrown: " + e);
            e.printStackTrace();
            throw new Error(e);
        }
    }


    /**
     * To deserialize a list serialized with this method, use the
     * method deserializeClassList.
     * @throws IOException 
     */
    public static ArrayList<String> serializeClassList(ArrayList<Class<?>> cl) {
    	if (cl == null) throw new IllegalArgumentException("cl should not be null.");
    	// Create an ArrayList of Strings corresponding to the class names,
    	// and serialize it.
    	ArrayList<String> listToSerialize = new ArrayList<String>();
    	for (Class<?> c : cl) {
    		if (c == null) throw new IllegalArgumentException("classes in list should not be null.");
    		listToSerialize.add(c.getName());
    	}
    	return listToSerialize;
    }
    
    @SuppressWarnings("unchecked")
	public static ArrayList<Class<?>> deserializeClassList(ArrayList<String> l) {
    	if (l == null) throw new IllegalArgumentException("l should not be null.");
    	ArrayList<Class<?>> ret = new ArrayList<Class<?>>();
    	for (String className : l) {
    		if (className == null) throw new IllegalArgumentException("class names in list should not be null.");
    		ret.add(classForName(className));
    	}
    	return ret;
    }
    
    /**
     * TODO Say why serialize a class in this way, since it is already serializable.
     */
    public static String serializeClass(Class<?> c) {
        return c.getName();
    }

    public static Class<?> deserializeClass(String className) {
        return classForName(className);
    }

    private static Class<?> classForName(String className) {
    	if (className.equals("void"))
            return void.class;
        if (PrimitiveTypes.isPrimitiveOrStringTypeName(className)) {
            return PrimitiveTypes.getPrimitiveTypeOrString(className);
        } else {
            try {
				return Class.forName(className);
			} catch (ClassNotFoundException e) {
				throw new Error(e);
			}
        }
	}

    public static String serializeMethod(Method m) {
      StringBuilder b = new StringBuilder();
      b.append(m.getDeclaringClass().getName());
      b.append(".");
      b.append((m.getName()));
      b.append(UtilMDE.arglistFromJvm(Util.createArgListJVML(m.getParameterTypes())));
      return b.toString();
    }

    public static Method deserializeMethod(String s) {
      return (Method) deserializeMethodOrCtor(s, false);
    }

    public static String serializeConstructor(Constructor<?> m) {
      StringBuilder b = new StringBuilder();
      b.append(m.getDeclaringClass().getName());
      b.append(".");
      b.append("<init>");
      b.append(UtilMDE.arglistFromJvm(Util.createArgListJVML(m.getParameterTypes())));
      return b.toString();
    }

    public static Constructor<?> deserializeConstructor(String s) {
      return (Constructor<?>) deserializeMethodOrCtor(s, true);
    }

    private static Member deserializeMethodOrCtor(String s, boolean isCtor) {
      if (s == null) throw new IllegalArgumentException("s cannot be null.");
       int openPar = s.indexOf('(');
       int closePar = s.indexOf(')');
       // Verify only one open/close paren, and close paren is last char.
       assert openPar == s.lastIndexOf('(') : s;
       assert closePar == s.lastIndexOf(')') : s;
       assert closePar == s.length() - 1;
       String clsAndMethod = s.substring(0, openPar);
       int lastDot = clsAndMethod.lastIndexOf('.');
       // There should be at least one dot, separating class/method name.
       assert lastDot >= 0;
       String clsName = clsAndMethod.substring(0, lastDot);
       String methodName = clsAndMethod.substring(lastDot + 1);
       if (isCtor)
         assert methodName.equals("<init>");
       String argsOneStr = s.substring(openPar + 1, closePar);
       
       // Extract parameter types.
       Class<?>[] argTypes = new Class<?>[0];
       if (argsOneStr.trim().length() > 0) {
         String[] argsStrs = argsOneStr.split(",");
         argTypes = new Class<?>[argsStrs.length];
         for (int i = 0 ; i < argsStrs.length ; i++) {
           argTypes[i] = Reflection.classForName(argsStrs[i].trim());
         }
       }
       
       Class<?> cls = Reflection.classForName(clsName);
       try {
         if (isCtor)
           return cls.getConstructor(argTypes);
         else
           return cls.getMethod(methodName, argTypes);
      } catch (Exception e) {
        throw new Error(e);
      }
    }
    
	public static String serializeThrowPoint(StackTraceElement throwPoint) {
		if (throwPoint == null) 
			throw new IllegalArgumentException("throwPoint cannot be null.");
		StringBuilder b = new StringBuilder();
		b.append(throwPoint.getClassName());
		b.append(":");
		b.append(throwPoint.getMethodName());
		b.append(":");
		b.append(throwPoint.getFileName());
		b.append(":");
		b.append(throwPoint.getLineNumber());
		return b.toString();
	}
	
	public static StackTraceElement deserializeThrowPoint(String s) {
		if (s == null) throw new IllegalArgumentException("s cannot be null.");
		String[] split = s.split(":");
		assert split.length == 4;
		return new StackTraceElement(split[0], split[1], split[2], Integer.parseInt(split[3]));
	}
}
