package randoop.branchanalysis;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import randoop.Sequence;
import randoop.util.Util;
import utilMDE.Pair;
import utilMDE.UtilMDE;
import cov.Branch;

/**
 * A collection of frontier branches and sequences that reach them.
 * A DataFlowInput is the input to the DataFlow analysis. 
 */
public class DataFlowInput implements Serializable {

	private static final long serialVersionUID = -3010962783887743548L;

	 // Maps a branch to a set of sequences that cover the branch.
	public Map<Branch, Set<Sequence>> frontierMap;
	
	public DataFlowInput(Map<Branch, Set<Sequence>> frontierMap) {
		this.frontierMap = frontierMap;
	}
	
	/**
	 * Create a new DataFlowInput from a text file.
	 * 
	 * The text file consists of a list of records. Each record is as follows:
	 * 
	 * START RECORD
	 * BRANCH <branch-description>
	 * SEQUENCE <sequence-description>
	 * END RECORD
	 *
	 * Where <branch-description> is a string that can be parsed
	 * by the method cov.OneBranchInfo.parse(String), and <sequence-description>
	 * is a string that can be parsed by the method
	 * randoop.SequenceParser.parse(String). The BRANCH and SEQUENCE
	 * definition can span multiple lines, in which case each line in the
	 * definition, except the last, should be terminated with a backslash ("\").
	 * 
	 * Blank lines and comments between records are allowed and ignored.
	 * Comments are lines starting with "#".
	 * 
	 * The records are read and used to populate the frontierMap field of the
	 * new DataFlowInput object. If two records specify the same branch, the
	 * two sequences are added to the same set.
	 * 
	 * The stats field is left null.
	 * 
	 * @param A text file containing a description of branches and sequences.
	 *        If inFile ends in ".gz" it will be read as a compressed file.
	 */
	public static DataFlowInput parse(String inFile) {
	  if (inFile == null || inFile.length() == 0)
	    throw new IllegalArgumentException("Illegal input file name: " + inFile);
	  
	  
	  
	  Map<Branch, Set<Sequence>> map = new LinkedHashMap<Branch, Set<Sequence>>();
	  
    BufferedReader reader;
    try {
      reader = UtilMDE.bufferedFileReader(inFile);
    } catch (IOException e) {
      throw new Error(e);
    }

    String line;
    try {
      line = reader.readLine();
      while (line != null) {
        line = line.trim();
        if (line.equals("") || line.startsWith("#")) {
          // do nothing.
        } else if (line.startsWith("START RECORD")) {
          Pair<Branch, Sequence> brAndSeq = parseRecord(readOneRecord(reader));
          
          Set<Sequence> set = map.get(brAndSeq.a);
          if (set == null) {
            set = new LinkedHashSet<Sequence>();
            map.put(brAndSeq.a, set);
          }
          set.add(brAndSeq.b);
        } else {
          throw new IllegalArgumentException("Expected string \"START RECORD\" but got " + line);
        }
        line = reader.readLine();
      }
    } catch (IOException e) {
      throw new Error(e);
    }
    
    return new DataFlowInput(map);
	}

	@SuppressWarnings("deprecation") // See http://bugs.sun.com/bugdatabase/view_bug.do;:WuuT?bug_id=4094886
  private static Pair<Branch, Sequence> parseRecord(String record) {
	  try {
	    
	    String[] lines = removeWhiteLines(record.split(Util.newLine));
	    assert lines[0].trim().equals("BRANCH");
	    // Next line is the branch.
	    Branch branch = Branch.parse(lines[1]);
	    assert lines[2].trim().equals("SEQUENCE");
	    // Line indices 3--end is the sequence.
	    List<String> statements = new ArrayList<String>();
	    for (int i = 3 ; i < lines.length ; i++) {
	      statements.add(lines[i]);
	    }
	    Sequence sequence = Sequence.parse(statements);

	    return new Pair<Branch, Sequence>(branch, sequence);
	  } catch (Exception e) {
	    throw new Error(e);
	  }
	}

  private static String[] removeWhiteLines(String[] lines) {
    List<String> newLines = new ArrayList<String>();
    for (String l : lines) {
      l = l.trim();
      if (l.length() == 0 || l.charAt(0) == '#')
        continue;
      newLines.add(l);
    }
    return newLines.toArray(new String[0]);
  }

  private static String readOneRecord(BufferedReader reader) throws IOException {
    StringBuilder record = new StringBuilder();
    String line = reader.readLine();
    while (line != null && !line.equals("END RECORD")) {
        line = line.trim();
        record.append(line + Util.newLine);
        line = reader.readLine();
    }
    return record.toString();
  }
  
  /**
   * Output this DataFlowInput as a text file.
   * @param outFile The file where output is to be written.
   * If outFile ends in ".gz" it will be output as a compressed file.
   */
  public void toParseableFile(String outFile) {
    if (outFile == null || outFile.length() == 0)
      throw new IllegalArgumentException("Illegal output file name: " + outFile);

    try {
      BufferedWriter out = UtilMDE.bufferedFileWriter(outFile);
      for (Map.Entry<Branch, Set<Sequence>> e : frontierMap.entrySet()) {
        for (Sequence seq : e.getValue()) {
          // Print one record.
          out.append("START RECORD\n\n");
          out.append("BRANCH\n");
          out.append(e.getKey().toString());
          out.append("\n\n");
          out.append("SEQUENCE\n");
          out.append(seq.toParseableString());
          out.append("\n\n");
          out.append("END RECORD\n\n");
        }
      }
      out.close();
    } catch (IOException e) {
      throw new Error(e);
    }
  }
}
