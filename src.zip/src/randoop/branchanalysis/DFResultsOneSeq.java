package randoop.branchanalysis;

import java.io.Serializable;
import java.util.Set;
import java.util.LinkedHashSet;

import cov.CoverageAtom;

import randoop.Sequence;
import randoop.Variable;

/**
 * Encapsulates the results of the branch analysis for a given
 * sequence and its frontier branch.
 */
public class DFResultsOneSeq implements Serializable {

	private static final long serialVersionUID = -7983260094515559715L;

    /**
     * Class that contains information about the values in the frontier
     */
    public static class VariableInfo implements Serializable {
        private static final long serialVersionUID = 20080625L;
        public Variable value;
        public Set<String> branch_compares = new LinkedHashSet<String>();
        public VariableInfo (Variable value) {
            this.value = value;
        }
        public void add_branch_compare (String compared_to) {
            branch_compares.add (compared_to);
        }
        public String toString() {
            return value + ":" + branch_compares;
        }
    }

	public Sequence sequence;
	public CoverageAtom frontierBranch;
	public Set<VariableInfo> values;

	public DFResultsOneSeq(Sequence sequence,
			CoverageAtom frontierBranch,
			Set<VariableInfo> values) {
		this.sequence = sequence;
		this.frontierBranch = frontierBranch;
		this.values = values;
	}

    @Override
	public String toString() {
        return String.format ("seq: %s, branch %s, values: %s",
                              sequence.toCodeString(), frontierBranch, values);
    }

}
