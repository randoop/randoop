package randoop.branchanalysis;

import java.io.Serializable;
import java.util.List;

public class DataFlowOutput implements Serializable {

	private static final long serialVersionUID = -4008574058179157696L;
	
	public List<DFResultsOneSeq> results;

	public DataFlowOutput(List<DFResultsOneSeq> results) {
		this.results = results;
	}

}
