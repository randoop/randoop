package randoop;

import java.util.ArrayList;
import java.util.List;

import randoop.util.PrimitiveTypes;

/**
 * A sequence that can be mutated (unlike a Sequence, which is immutable).
 * The "M" stands for "Mutable".
 */
public class MSequence {

	public List<MStatementCall> statements;

	public MStatementCall getStatementWithInputs(MVariable v) {
		return statements.get(getIndex(v));
	}

	public int getIndex(MVariable v) {
		if (v == null) throw new IllegalArgumentException();
		if (v.owner != this) throw new IllegalArgumentException();
		for (int i = 0 ; i < statements.size() ; i++) {
			MStatementCall st = statements.get(i);
			if (st.result == v)
				return i;
		}
		throw new BugInRandoopException();
	}

	public int size() {
		return statements.size();
	}

	public MVariable getVariable(int i) {
		if (i < 0 || i >= this.size()) throw new IllegalArgumentException();
		return this.statements.get(i).result;
	}

	public Sequence toFastSequence() {
		Sequence seq = new Sequence();
		for (int i = 0 ; i < this.size() ; i++) {
			List<Variable> inputs = new ArrayList<Variable>();
			for (MVariable sv : this.statements.get(i).inputs) {
				inputs.add(seq.getVariable(sv.getIndex()));
			}
			seq = seq.extend(this.statements.get(i).statement, inputs);
		}
		return seq;
	}

	/** A compilable (Java source code) representation of this sequence. */
	public String toCodeString() {
		StringBuilder b = new StringBuilder();
		for (int i = 0; i < size(); i++) {
			printStatement(b, i, true);
		}
		return b.toString();
	}

  // CODE COPIED FROM SEQUENCE. XXX AVOID DUPLICATION.
	void printStatement(StringBuilder b, int index, boolean printPrimitiveDeclarationStatements) {
		if (!printPrimitiveDeclarationStatements && statements.get(index).statement instanceof PrimitiveOrStringOrNullDecl)
			return;
		// Get strings representing the inputs to this statement. Example: {
		// "var2", "(int)3" }
		List<MVariable> inputs = statements.get(index).inputs;
		String[] inputString = new String[inputs.size()];
		int i = 0;
		for (MVariable v : inputs) {
			if (!printPrimitiveDeclarationStatements && getStatementWithInputs(v).statement instanceof PrimitiveOrStringOrNullDecl) {
				inputString[i++] =  castMaybe(v) + "(" + PrimitiveTypes.toCodeString(((PrimitiveOrStringOrNullDecl) getStatementWithInputs(v).statement).getValue()) + ")";
			} else {
				inputString[i++] = v.toString();
			}
		}
		statements.get(index).statement.appendCode(getVariable(index).getName(), inputString, b);
	}
	
	 // CODE COPIED FROM SEQUENCE. XXX AVOID DUPLICATION.
  private static String castMaybe(MVariable v) {
    if (v.getType().equals(int.class)) return "(int)";
    if (v.getType().equals(long.class)) return "(long)";
    if (v.getType().equals(short.class)) return "(srhot)";
    if (v.getType().equals(float.class)) return "(float)";
    if (v.getType().equals(double.class)) return "(double)";
    if (v.getType().equals(byte.class)) return "(byte)";
    return "";
  }



}
