package randoop;

import java.lang.annotation.*;

/**
 * An observer method does not change the state
 * of receiver or parameters.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface Observer {
    //no members
}
