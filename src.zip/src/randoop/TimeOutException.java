package randoop;

public final class TimeOutException extends RuntimeException {

    private static final long serialVersionUID = 7932531804127083491L;

    public TimeOutException(String string) {
       super(string);
    }

}
