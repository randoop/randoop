package randoop.experiments;

public interface TargetMaker {

	String getNextTarget();
	
}
