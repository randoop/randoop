package randoop.experiments;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import randoop.util.Files;

public class ComputeCodeStats {
	
	public static void main(String[] args) throws IOException {
		for (ExperimentBase exp : ExperimentBase.getExperimentBasesFromFiles(args)) {
			computeStats(exp);
		}
	}

	private static void computeStats(ExperimentBase exp) throws FileNotFoundException {

		File sourceListingFile = new File("sources.txt");

		FileOutputStream fos = new FileOutputStream("log.txt");
		PrintStream err = new PrintStream(fos);

		System.out.println("========== Deleting .class files in " + exp.classDirAbs);
		List<String> delCmd = new ArrayList<String>();
		delCmd.add("find");
		delCmd.add(exp.classDirAbs);
		delCmd.add("-name");
		delCmd.add("*.class");
		delCmd.add("-delete");
		ExperimentBase.printCommand(delCmd, true, true);
		int retval = Command.exec(delCmd.toArray(new String[0]),
				new PrintStream(new FileOutputStream(sourceListingFile)),
				System.err, "", false, Integer.MAX_VALUE, null);
		if (retval != 0) {
			System.out.println("find command exited with error code " + retval);
			System.out.println("File log.txt contains output of stderr.");
			System.exit(1);
		}

		System.out.println("========== Creating list of .java files for experiment (stored in "
				+ sourceListingFile + ")");
		List<String> findCmd = new ArrayList<String>();
		findCmd.add("find");
		findCmd.add(exp.classDirAbs);
		findCmd.add("-name");
		findCmd.add("*.java");
		ExperimentBase.printCommand(findCmd, true, true);
		retval = Command.exec(findCmd.toArray(new String[0]),
				new PrintStream(new FileOutputStream(sourceListingFile)),
				System.err, "", false, Integer.MAX_VALUE, null);
		if (retval != 0) {
			System.out.println("find command exited with error code " + retval);
			System.out.println("File log.txt contains output of stderr.");
			System.exit(1);
		}


		System.out.println("========== Compiling subject program: " + exp.experimentName);
		List<String> compile = new ArrayList<String>();
		compile.add("javac");
		compile.add("-J-Xmx1700m");
		compile.add("-classpath");
		compile.add(exp.classPath);
		compile.add("-g");
		compile.add("@" + sourceListingFile.getAbsolutePath());
		ExperimentBase.printCommand(compile, true, false);
		retval = Command.exec(compile.toArray(new String[0]), System.out, err, "", true,
				Integer.MAX_VALUE, null);
		if (retval != 0) {
			System.out.println("javac command exited with error code " + retval);
			System.out.println("File log.txt contains output of stderr.");
			System.exit(1);
		}

		File covDir = new File(exp.experimentName + "-covinst");

		System.out.println("========== Removing directory for coverage-instrumented sources: " + covDir.getName());
		Files.deleteRecursive(covDir);
		
		System.out.println("========== Instrumenting subject program for coverage: " + exp.experimentName);
		List<String> instrument = new ArrayList<String>();
		instrument.add("java");
		instrument.add("-ea");
		instrument.add("-Xmx1700m");
		instrument.add("-classpath");
		instrument.add(exp.classPath);
		instrument.add("simplecov.Instrument");
		instrument.add("--destination=" + covDir.getAbsolutePath());
		instrument.add("--files=" + sourceListingFile);
		ExperimentBase.printCommand(instrument, true, false);
		retval = Command.exec(instrument.toArray(new String[0]), System.out, err, "", true,
				Integer.MAX_VALUE, null);
		if (retval != 0) {
			System.out.println("command exited with error code " + retval);
			System.out.println("File log.txt contains output of stderr.");
			System.exit(1);
		}
		
		System.out.println("========== Creating list of coverage-instrumented .java files for experiment (stored in "
				+ sourceListingFile + ")");
		List<String> findInstrSources = new ArrayList<String>();
		findInstrSources.add("find");
		findInstrSources.add(covDir.getName());
		findInstrSources.add("-name");
		findInstrSources.add("*.java");
		ExperimentBase.printCommand(findInstrSources, true, true);
		retval = Command.exec(findInstrSources.toArray(new String[0]),
				new PrintStream(new FileOutputStream(sourceListingFile)),
				System.err, "", false, Integer.MAX_VALUE, null);
		if (retval != 0) {
			System.out.println("find command exited with error code " + retval);
			System.out.println("File log.txt contains output of stderr.");
			System.exit(1);
		}

		System.out.println("========== Compiling coverage-instrumented .java files: " + exp.experimentName);
		List<String> compileInstr = new ArrayList<String>();
		compileInstr.add("javac");
		compileInstr.add("-J-Xmx1700m");
		compileInstr.add("-classpath");
		compileInstr.add(exp.classPath);
		compileInstr.add("-g");
		compileInstr.add("@" + sourceListingFile.getAbsolutePath());
		ExperimentBase.printCommand(compileInstr, true, false);
		retval = Command.exec(compileInstr.toArray(new String[0]), System.out, err, "", true,
				Integer.MAX_VALUE, null);
		if (retval != 0) {
			System.out.println("javac command exited with error code " + retval);
			System.out.println("File log.txt contains output of stderr.");
			System.exit(1);
		}

	}
}
