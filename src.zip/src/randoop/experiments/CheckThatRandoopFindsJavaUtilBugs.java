package randoop.experiments;

import java.io.*;
import java.lang.reflect.Field;
import java.util.*;

import randoop.EqualsToItself;




// Looks in Randoop's output for a set of expected bugs when running
// Randoop on the java.util classes.
//
//TO ADD A BUG THAT SHOULD BE FOUND:
// (1) Declare a public static boolean field, initialize to false.
// (2) modify lookForBugsInOneTest(List<String>) so that if the bug
//     is found in the testclasses (comprising the given lines of text)
//     the the field is set to true, and if the bug is not found
//     the field remains false.
public class CheckThatRandoopFindsJavaUtilBugs {
    
    @SuppressWarnings("unused") // It's actually used, via reflection.
    public static boolean foundCollectionsEqOO = false;

    // Not a bug, but Randoop should generate a testclasses for this.
    @SuppressWarnings("unused") // It's actually used, via reflection.
    public static boolean foundFormatterClosed = false;
    
    public static void main(String[] args) throws IOException, IllegalArgumentException, IllegalAccessException {
        
            String dirname = args[0];
            String fileprefix = args[1];
            
            File dir = new File(dirname);
            
            for (File f : dir.listFiles()) {
                if (f.getName().startsWith(fileprefix) && f.getName().endsWith(".java")) {
                    lookForBugs(f);
                }
            }
            
            printBugSummary();
            
            if (!foundAllBugs()) {
                System.out.println("DID NOT FIND ALL EXPECTED BUGS.");
                System.out.println("LOOK IN class " + CheckThatRandoopFindsJavaUtilBugs.class.getName() + " for specifics.");
                System.exit(1);
            }
    }

    private static void printBugSummary() throws IllegalArgumentException, IllegalAccessException {
        
        for (Field f : CheckThatRandoopFindsJavaUtilBugs.class.getDeclaredFields()) {
            if (f.getType().equals(boolean.class)) {
                System.out.println(f.getName() + " " + f.getBoolean(null));
            }
        }

    }

    private static boolean foundAllBugs() throws IllegalArgumentException, IllegalAccessException {
        for (Field f : CheckThatRandoopFindsJavaUtilBugs.class.getDeclaredFields()) {
            if (f.getType().equals(boolean.class)) {
                if (f.getBoolean(null) == false)
                    return false;
            }
        }
        return true;
    }

    private static void lookForBugs(File f) throws IOException {
        
        BufferedReader reader = new BufferedReader(new FileReader(f));
        String line = reader.readLine();
        List<String> linesForOneTest = new ArrayList<String>();
        while (line != null) {
            if (!line.trim().equals("")) {
                if (line.startsWith("public void testclasses")) {
                    // We reached the start of a testclasses. Process
                    // previous testclasses.
                    lookForBugsInOneTest(Collections.unmodifiableList(linesForOneTest));
                    // Remove lines for last-processed testclasses.
                    linesForOneTest = new ArrayList<String>();
                } else {
                    linesForOneTest.add(line);
                }
            }
            line = reader.readLine();
        }
        reader.close();
    }

    private static void lookForBugsInOneTest(List<String> lines) {
        
        lookForEqOOBug(lines);
        lookForFormatterClosed(lines);
    }
    
    //  Not a bug, but Randoop should generate a testclasses for this.
    // Test looks like this:
    //  public void test1() throws Throwable {
    //  java.util.Formatter var0 = new java.util.Formatter();
    //    var0.close();
    //    //ToStringThrowsException java.util.FormatterClosedException
    //    if (var0 !== null){
    //     var0.toString();
    //    }
    //  }
    private static void lookForFormatterClosed(List<String> lines) {
        String contractNameLine = lines.get(lines.size() - 5);
        String callLine = lines.get(lines.size() - 3);
        if (contractNameLine.contains("ToStringThrowsException java.util.FormatterClosedException")
                && callLine.contains("toString()"))
            foundFormatterClosed = true;
    }

    // Look for bug that creates collection s.t. o.equals(o)==true.
    // This bug happens in
    //   Collections.unmodifiableSet,
    //   Collections.synchronizedSortedSet,
    //   Collections.synchronizedSortedSet,
    //   and others.
    // As long as Randoop finds it for at least one class, we say it found it.
    //
    // Here is what the testclasses looks like:
    //
    //  public void test13() throws Throwable {
    //  ...
    //  java.util.SortedSet var19 = java.util.Collections.unmodifiableSortedSet((java.util.SortedSet)var17);
    //  //EqualsNotReflexive
    //  assertTrue(var19.equals(var19) == true);
    //  }
    private static void lookForEqOOBug(List<String> lines) {
        String contractNameLine = lines.get(lines.size() - 3);
        String methodCallLine = lines.get(lines.size() - 4);
        if (contractNameLine.contains(EqualsToItself.class.getSimpleName())
                && methodCallLine.contains("java.util.Collections")
                && methodCallLine.contains("Set"))
            foundCollectionsEqOO = true;
    }

}
