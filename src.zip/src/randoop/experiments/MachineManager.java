package randoop.experiments;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;


/**
 * A thread that issues make targets on a specified machine. The manager
 * enters a loop. At each iteration, it asks its spawner for the next
 * target to execute. If there are no more targets, the thread dies.
 * 
 * If there is a target and this manager's machine name is "local",
 * the manager issues the command
 * 
 *   make -C $RANDOOP_HOME/systemtests <target>
 *   
 * If the machine name is other than "local", the target issues the
 * command
 * 
 *   ssh <machine> make -C $RANDOOP_HOME/systemtests <target>
 */
public class MachineManager extends Thread {

  String machine;

  private MultiMachineRunner spawner;

  protected Process fproc;

  protected boolean fswapOut = false;

  ByteArrayOutputStream out = null;

  public MachineManager(String machine, MultiMachineRunner spawner) {
    this.machine = machine;
    this.spawner = spawner;
  }

  @Override
public void run() {
    for (;;) {
      if (fswapOut) {
        break;
      }
      String e = spawner.nextTarget();
      if (e == null) {
        break;
      } else {

        List<String> command = new ArrayList<String>();
        if (!machine.equals("local")) {
          command.add("ssh");
          command.add(machine);
        }
        command.add("make");
        command.add("-C");
        command.add(MultiMachineRunner.RANDOOP_HOME
            + File.separator
            + "systemtests");
        command.add(e);

        fproc = null;
        int exitVariable = 0;
        //try {
        System.out.println("Machine " + machine + " starting experiment " + e);
        if (MultiMachineRunner.verbose) {
          System.out.println("Executing command:" + e);
        }

        out = new ByteArrayOutputStream();
        PrintStream str = new PrintStream(out);

        exitVariable = Command.exec(command.toArray(new String[0]), str, str,  "", false);

        if (exitVariable != 0) {
          System.out
          .println("Return value of process was != 0. Machine "
              + machine
              + " will get a new experiment. Command was: <<<"
              + command
              + ">>> Output of the command was: <<<"
              + out.toString()
              + ">>>");
          spawner.markTargetEndedWithError(e);
        } else {
          System.out.println("Machine " + machine + " finished experiment " + e + " (exit " + exitVariable + ")");
          spawner.markTargetDone(e);
        }
      }
    }
    System.out.println("Machine " + machine + " has no more work.");
  }
}