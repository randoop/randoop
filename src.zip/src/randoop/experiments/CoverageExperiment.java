package randoop.experiments;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import randoop.Globals;

public class CoverageExperiment {

    private ExperimentBase base;

    // Input generation time (input to randoop).
    protected String time;
    // Prefix to use when generating junit tests (input to randoop).
    protected String junitNamePrefix;
    // Randoop-generated files.
    protected List<String> junitFiles;
    // use-threads option (whether to execute each input in its own thread).
    protected String useThreads;

    private static boolean verbose = true;

    public CoverageExperiment(ExperimentBase base) {
        this.base = base;
        this.time = base.extraProperties.getProperty("TIME");
        if (time == null) throw new IllegalArgumentException("TIME not found.");
        this.useThreads = base.extraProperties.getProperty("USETHREADS");
        if (useThreads == null) throw new IllegalArgumentException("USETHREADS not found.");
        String packageNameUnderscore = this.base.experimentName.replace('.', '_');
        this.junitNamePrefix = "Test_" + packageNameUnderscore;
    }

   @Override
   public String toString() {
       StringBuilder b = new StringBuilder(this.base.toString());
       b.append("time:" + this.time + Globals.lineSep);
       b.append("junitNamePrefix:" + this.junitNamePrefix + Globals.lineSep);
       b.append("junitFiles:" + this.junitFiles + Globals.lineSep);
       return b.toString();
   }

   private void clean() {
       System.out.println("========== Removing files from previous run of this experiment.");
       List<String> rm = new ArrayList<String>();
       rm.add("rm");
       this.junitFiles = findGeneratedJunitFiles();
       if (junitFiles.size() == 0)
    	   return;
       rm.addAll(this.junitFiles);
       if (verbose)
           ExperimentBase.printCommand(rm, true, true);
       Command.runCommandOKToFail(rm.toArray(new String[0]), "CLEAN", true, "", true);
   }

   private void run() throws IOException {
	   System.out.println("========== RUNNING EXPERIMENT:");
	   System.out.println(toString());
		   // Run randoop.
		   clean();
		   try {
			   callRandoop();
		   } catch (Command.KillBecauseTimeLimitExceed e) {
			   System.out.println("Run of randoop terminated because it appears to be nonterminating.");
		   }
   }

   private void callRandoop() throws IOException {
       System.out.println("========== Running Randoop.");
       List<String> randoop = new ArrayList<String>();
       randoop.add("java");
       randoop.add("-ea");
       randoop.add("-Xmx1700m");
       randoop.add("-classpath");
       randoop.add(this.base.classPath);
       randoop.add("randoop.main.Main");
       randoop.add("genregressions");
       randoop.add("--progressinterval=1");
       randoop.add("--minimize");
       randoop.add("--log=temp.log");
       randoop.add("--track-coverage=cobertura.ser");
       randoop.add("--branchdir");
       randoop.add("--maxsize=50");
       randoop.add("--print-stats=false");
       randoop.add("--dont-output-tests");
       randoop.add("--usethreads=" + this.useThreads);
       randoop.add("--classlist=" + this.base.targetClassListFile);
       //randoop.add("--timelimit=5");
       randoop.add("--timelimit=" + this.time);
       randoop.add("--junitclass=" + this.junitNamePrefix);

       if (!this.base.methodOmitPattern.equals(""))
           randoop.add("--omitmethods=" + this.base.methodOmitPattern);
       if (verbose)
           ExperimentBase.printCommand(randoop, true, true);
       //ByteArrayOutputStream bos = new ByteArrayOutputStream();
       FileOutputStream fos = new FileOutputStream("temp.txt");
       PrintStream err = new PrintStream(fos);
       // Kill the process if randoop takes 100 seconds more to execute than the time limit
       // (this likely means it's definitely stuck).
       int killAfterMillis = Integer.parseInt(this.time) * 1000 + 100000;
       int ret = Command.exec(randoop.toArray(new String[0]), System.out, err, "RUN JOE", true, killAfterMillis, null);
       if (ret != 0)
         System.out.println("WARNING! RETURN CODE != 0");
       //Command.runCommand(randoop.toArray(new String[0]), "RUN JOE", true, "", true);

       this.junitFiles = findGeneratedJunitFiles();
   }

   private List<String> findGeneratedJunitFiles() {
       File currentDir = new File(System.getProperty("user.dir"));
       List<String> retval = new ArrayList<String>();
       for (String fileName : currentDir.list()) {
           if (fileName.startsWith((this.junitNamePrefix)))
               retval.add(fileName);
       }
       return retval;
   }

   /**
    * args[0] is the name of the filename to write experiment results to.
    * The rest of the args are filenames containing experiment properties.
    */
   public static void main(String[] args) throws IOException     {
       List<CoverageExperiment> CoverageExperiments =
    	   getCoverageExperiments(ExperimentBase.getExperimentBasesFromFiles(args));
       for (CoverageExperiment run : CoverageExperiments) {
           run.run();
       }
   }

   private static List<CoverageExperiment> getCoverageExperiments(List<ExperimentBase> name) {
       List<CoverageExperiment> retval = new ArrayList<CoverageExperiment>();
       for (ExperimentBase base : name) {
           retval.add(new CoverageExperiment(base));
       }
       return retval;
   }


}
