package randoop;






/**
 * An execution visitor that calls observers, but does not record values for them.
 * This makes test generation much faster but results in tests that inlude calls that are sure to fail at runtime. 
 */
public final class ObserverCallVisitor implements ExecutionVisitor {

	public boolean visitAfter(ExecutableSequence sequence, int i) {
		// TODO Auto-generated method stub
		throw new RuntimeException("not implemented");
	}

	public void visitBefore(ExecutableSequence sequence, int i) {
		// TODO Auto-generated method stub
		throw new RuntimeException("not implemented");
	}

//    private final PurityInfo purityInfo;
//    
//    public ObserverCallVisitor(PurityInfo observerInfo) {
//        this.purityInfo = observerInfo;
//    }
//
//    public boolean visitAfter(ExecutableSequence s, int idx) {
//        
//        int sSize = s.sequence.size();
//        if (idx < (sSize -1))
//            return false;
//        
//        for (int i = 0; i < sSize ; i++) {
//            if (!(s.getResult(i) instanceof NormalExecution))
//                continue;
//            NormalExecution e = (NormalExecution)s.getResult(i);
//            if ((s.sequence.getStatement(i) instanceof PrimitiveOrStringOrNullDecl)) 
//                continue;
//            Class<?> tc = s.sequence.getStatement(i).getOutputType();
//            if (tc.equals(void.class))
//                continue; // no return value.
//            Object o = e.getRuntimeVariable();
//            if (o == null) 
//                continue; // null value.
//            Class<?> c = tc;
//            if (!Reflection.canBeUsedAs(o.getClass(), c)) {
//                // This can happen if a methodCallInfo.returnIndexCast == true
//                // but at runtime, the method actually returns a different
//                // class.
//                continue;
//            }
//            if (PrimitiveOrStringObservation.isPrimitiveOrString(o))
//                continue; // prim value
//            
//            Variable value = s.sequence.getVariable(i);
//            Set<Method> observers = purityInfo.getObservers(c);
//            for (Method m : observers) {
//                s.addDecoration(idx, new ObserverMethodCallDecoration(m, s, value));        
//            }
//        }
//        return true;
//    }
//
//    public void visitBefore(ExecutableSequence s, int idx) {
//
//    }

}

