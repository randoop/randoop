package randoop;

import java.lang.annotation.*;

/**
 * A method that should be tested by randoop.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.CONSTRUCTOR, ElementType.METHOD })
public @interface Testable {
    //no members
}
