package randoop;

/**
 * Communicates the result of executing one statement in a sequence.
 * 
 * The "result" can be one of two things:
 * 
 * <ul>
 *   <li> If the statement terminates normally, then the result is
 *        such that r.isNormalExecution()==true, r.isExceptionalExecution()==false,
 *        and r.getRuntimeVariable() returns the objects that the statement returns
 *        (null for void method calls).
 *        
 *        
 *   <li> If the statement throws an exception, then the result is
 *        such that r.isNormalExecution()==false, r.isExceptionalExecution()==true,
 *        and r.getException() returns the thrown exception.
 * </ul>
 * 
 */
public class StatementExecutionResult {
    private final Object result;
    private final Throwable exception;
    private StatementExecutionResult(Object result, Throwable exception) {
        if (exception != null && result != null)
            throw new IllegalArgumentException();
        this.result = result;
        this.exception = exception;
    }
    public boolean isNormalExecution() {
        return this.exception == null;
    }
    public boolean isExceptionalExecution() {
        return this.exception != null;
    }
    
    /**
     * The object returned by getRuntimeVariable() is the actual runtime
     *        object created during execution of the sequence (call it s). This means that
     *        if you invoke s.execute(v) and then you invoke s.getResult(i).getRuntimeVariable(),
     *        the state of the object you get is the FINAL state of the object after s
     *        finished executing, NOT the state of the object after the i-th statement
     *        was executed. Similarly, if you invoke getRuntimeVariable() sometime in the
     *        middle of the execution of s (e.g. you're an ExecutionVisitor and you invoke
     *        getRuntimeVariable()), you'll get the state in whatever state it is at that
     *        point in the execution.
     */
    public Object getRuntimeVariable() {
    	if (!isNormalExecution())
    		throw new IllegalStateException("Execution is not normal execution.");
    	return this.result;
    }
    public Throwable getException() {
        if (!isExceptionalExecution())
            throw new IllegalStateException("Execution did not throw an exception.");
        return this.exception;
    }
    public static StatementExecutionResult createExceptionResult(Throwable exception) {
        return new StatementExecutionResult(null, exception);
    }
    public static StatementExecutionResult createNormalResult(Object result) {
        return new StatementExecutionResult(result, null);
    }

    /** Warning: this method calls toString() of code under test, which may have
     * arbitrary behavior. We use this method in randoop.test.SequenceTests.
     */
    @Override
    public String toString() {
        StringBuilder b = new StringBuilder();
        b.append("// <StatementExecutionResult object=" + toStringSafe(result));
        b.append(", exception=" + toStringSafe(exception));
        b.append(">;");
        return b.toString();
    }

    private static String toStringSafe(Object o) {
        try {
            return o.toString();
        } catch (Exception e) {
            // do nothing.
        }
        return "<undefined>";
    }
}
