package randoop;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;





public class NaiveRandomGeneratorFactory {

	List<StatementKind> allStatements;

	ArrayList<StatementKind> activeStatements = new ArrayList<StatementKind>();

	LinkedHashMap<Class<?>, Set<StatementKind>> missingTypesToStatements = new LinkedHashMap<Class<?>, Set<StatementKind>>();

	LinkedHashMap<StatementKind, Set<Class<?>>> inactiveStatements = new LinkedHashMap<StatementKind, Set<Class<?>>>();

	public NaiveRandomGeneratorFactory(List<StatementKind> statements) {
		allStatements = statements; // TODO make copy of statements instead.
		activeStatements = new ArrayList<StatementKind>();
		missingTypesToStatements = new LinkedHashMap<Class<?>, Set<StatementKind>>();
		inactiveStatements = new LinkedHashMap<StatementKind, Set<Class<?>>>();
		for (StatementKind st : allStatements) {
			Set<Class<?>> inputTypes = getInputTypesSet(st);
			if (inputTypes.isEmpty()) {
				activeStatements.add(st);
				continue;
			}
			inactiveStatements.put(st, new LinkedHashSet<Class<?>>(inputTypes));
			for (Class<?> cls : getInputTypesSet(st)) {
				Set<StatementKind> s = missingTypesToStatements.get(cls);
				if (s == null) {
					s = new LinkedHashSet<StatementKind>();
					missingTypesToStatements.put(cls, s);
				}
				s.add(st);
			}
		}

		if (activeStatements.isEmpty())
			throw new IllegalArgumentException("No active statements.");
	}

	private Set<Class<?>> getInputTypesSet(StatementKind st) {
		throw new RuntimeException("not implemented.");
	}

	@SuppressWarnings("unchecked")
	public NaiveRandomGenerator create() {
		NaiveRandomGenerator gen = new NaiveRandomGenerator();
		gen.availableTypes = new SubTypeSet();
		gen.typesToVals = new LinkedHashMap<Class<?>, Set<Variable>>();
		gen.sequence = new Sequence();
		gen.executionResults = new ArrayList<ExecutionOutcome>();
		gen.allStatements = allStatements;
		gen.activeStatements = new ArrayList<StatementKind>(activeStatements);
		gen.inactiveStatements = new LinkedHashMap<StatementKind, Set<Class<?>>>();
		for (Map.Entry<StatementKind, Set<Class<?>>> e : inactiveStatements
				.entrySet())
			gen.inactiveStatements.put(e.getKey(), new LinkedHashSet<Class<?>>(
					e.getValue()));
		gen.missingTypesToStatements = new LinkedHashMap<Class<?>, Set<StatementKind>>();
		for (Map.Entry<Class<?>, Set<StatementKind>> e : missingTypesToStatements
				.entrySet())
			gen.missingTypesToStatements.put(e.getKey(),
					new LinkedHashSet<StatementKind>(e.getValue()));
		//gen.repInvariantCheck();
		return gen;
	}
}
