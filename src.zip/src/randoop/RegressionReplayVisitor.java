package randoop;


/**
 * A visitor that expects a sequence with (perhaps) regression decorations.
 * For each such decoration, it replays the behavior and throws an exception
 * if it encounters a decoration that doesn't replay. 
 *
 */
public final class RegressionReplayVisitor implements ExecutionVisitor {

	public boolean visitAfter(ExecutableSequence sequence, int i) {
		// TODO Auto-generated method stub
		throw new RuntimeException("not implemented");
	}

	public void visitBefore(ExecutableSequence sequence, int i) {
		// TODO Auto-generated method stub
		throw new RuntimeException("not implemented");
	}

//    public void visitBefore(ExecutableSequence sequence, int i) {
//        // no body.
//    }
//
//    public boolean visitAfter(ExecutableSequence s, int i) {
//
//        if (i < s.sequence.size() - 1)
//            return true;
//
//        for (Observation d : s.getDecorations(i, RegressionDecoration.class)) {
//            RegressionDecoration rd = (RegressionDecoration)d;
//            MatchResult result = rd.replay(null);
//            if (!result.isSuccessful())
//                throw new ReplayFailureException(result.getErrorMessage(), rd);    
//        }
//        return true;
//    }
}


