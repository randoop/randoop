package randoop;

/**
 * The expression "x0".
 */
public final class ValueExpression implements Expression {

	public Object evaluate(Object... objects) {
		assert objects != null && objects.length == 1;
		return objects[0];
	}

	public int getArity() {
		return 1;
	}
}
