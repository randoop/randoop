package randoop.main;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import randoop.NaiveRandomGenerator;
import randoop.StatementKind;
import randoop.util.DefaultReflectionFilter;
import randoop.util.Randomness;
import randoop.util.Reflection;
import utilMDE.Options;
import utilMDE.Options.ArgException;

/**
 * Randomly generates test inputs using the naive generation algorithm.
 * 
 * Note: some command-line options from GenInputsAbstract have different
 * meaning, and some are not used at all.
 */
public class GenInputsNaive extends GenInputsAbstract {

	private static final String command = "gen-inputs-naive";

	private static final String pitch = "Generates inputs using naive generation algorithm.";

	private static final String commandGrammar = "gen-inputs-naive OPTIONS";

	private static final String where = "At least one class is specified via `--testclass' or `--classlist'.";

	private static final String summary = "Generates sequences of method calls using the naive generation algorithm.";

	private static final String input = "One or more names of classes to test. A class to test can be specified "
		+ "via the `--testclass=<CLASSNAME>' or `--classlist=<FILENAME>' options.";

	private static final String output = "Statistics of generation are output to stdout.";

	private static final String example = "java -jar randoop.jar gen-inputs-naive --testclass=java.util.Collections "
		+ " --testclass=java.util.TreeSet";

	private static Options options = new Options(GenInputsAbstract.class); 

	public GenInputsNaive() {
		super(command, pitch, commandGrammar, where, summary, null, input, output, example, options);
	}
 
	@Override
	public boolean handle(String[] args) throws RandoopTextuiException {

		try {
		  String[] nonargs = options.parse(args);
		  if (nonargs.length > 0) throw new ArgException("Unrecognized arguments: " + Arrays.toString(nonargs));
		} catch (ArgException ae) {
			System.out.println("ERROR while parsing command-line arguments (will exit): " + ae.getMessage());
		  System.exit (-1);
		}

		System.out.println("TIME=" + timelimit + ",SEQS=" + inputlimit);
		Randomness.reset(randomseed);

		// Find classes to test.
		List<Class<?>> classes = findClassesFromArgs(options);

        List<StatementKind> model = 
        Reflection.getStatements(classes, new DefaultReflectionFilter(omitmethods));
		
		try {
			NaiveRandomGenerator.generateSequences(model, inputlimit, maxsize);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		
//		List<Integer> li = new ArrayList<Integer>(NaiveRandomGenerator.smap.values());
//		Collections.sort(li);
//		Collections.reverse(li);
//		for (Integer i : li) {
//			System.out.println(i);
//		}
//		for (Map.Entry<Statement, Integer> e : NaiveRandomGenerator.smap.entrySet()) {
//			System.out.println(e.getValue() + "\t" + e.getKey().toStringShort());
//			
//		}
//		System.out.println("done.");
		return true;
	}

}
