package randoop.main;

public class RandoopTextuiException extends Exception {

	private static final long serialVersionUID = 1L;

	public RandoopTextuiException(String string) {
		super(string);
	}

}
