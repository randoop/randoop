package randoop.main;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import randoop.branchanalysis.DataFlowInput;
import randoop.util.Files;
import randoop.util.SerializationHelper;
import cov.Branch;

/**
 * Usage:
 *   PrintStats COVCLASSES RESULT_1 ... RESULT_N
 *   
 *   There must be at least one RESULT_i argument.
 *   
 *  COVCLASSES is a text file with a class name in each line.
 *  The total branches reported are the branches across these classes.
 *  These classes must be instrumented for coverage.
 *  
 *  RESULT_i is a file containing a single DataFlowInput object,
 *  created by a run of Randoop. PrintStats looks into
 *  the field DataFlowInput.stats.branchesCovered to determine the
 *  covered branches during the specific run of Randoop. The classes
 *  covered must be a subset of the classes in COVCLASSES.
 *
 */
public class PrintStats {
  
  public static void main(String[] args) throws IOException {
    
    if (args.length < 2) throw new IllegalArgumentException("Expected at least 2 arguments.");
    
    List<String> covclasses = Files.readWhole(args[0]);
        
    List<DataFlowInput> runs = new ArrayList<DataFlowInput>();
    for (int resulti = 1 ; resulti < args.length ; resulti++) {
      File resultsFile = new File(args[resulti]);
      if (!resultsFile.exists()) {
        System.out.println("DID NOT FIND FILE (WILL SKIP): " + resultsFile);
        continue;
      }
      DataFlowInput run = (DataFlowInput) SerializationHelper.readSerialized(resultsFile);
      runs.add(run);
    }
    
    Set<Branch> allBranches = new LinkedHashSet<Branch>();
    for (DataFlowInput in : runs) {
      throw new RuntimeException("TODO");
      //allBranches.addAll(in.stats.branchesCovered);
    }
    
    System.out.println("BRANCHES COVERED: " + allBranches.size());
  }

}
