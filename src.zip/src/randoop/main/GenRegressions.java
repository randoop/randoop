package randoop.main;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import randoop.BugInRandoopException;
import randoop.ExecutableSequence;
import randoop.ForwardGenerator;
import randoop.JunitFileWriter;
import randoop.RConstructor;
import randoop.RMethod;
import randoop.SeedSequences;
import randoop.Sequence;
import randoop.SequenceCollection;
import randoop.StatementKind;
import randoop.branchanalysis.DataFlowInput;
import randoop.util.DefaultReflectionFilter;
import randoop.util.Log;
import randoop.util.Randomness;
import randoop.util.Reflection;
import randoop.util.ReflectionExecutor;
import utilMDE.Options;
import utilMDE.Options.ArgException;
import cov.Branch;
import cov.Coverage;
import cov.CoverageAtom;

public class GenRegressions extends GenInputsAbstract {

	private static final String command = "genregressions";

	private static final String pitch = "Attempts to generate regression unit tests for a set of classes.";

	private static final String commandGrammar = "genregressions OPTIONS";

	private static final String where = "At least one class is specified via `--testclass' or `--classlist'.";

	private static final String summary = "Attempts to generate JUnit tests that "
			+ "capture the behavior of the classes under test. "
			+ "Randoop generates tests using feedback-directed random test generation. "
			+ "By construction, regression tests always pass. If you want Randoop to "
	                + "generate tests that uncover errors, see the `genfailures' command. ";

	private static final String input = "One or more names of classes to test. A class to test can be specified "
			+ "via the `--testclass=<CLASSNAME>' or `--classlist=<FILENAME>' options.";

	private static final String output = "A JUnit test suite (as one or more Java source files). The "
			+ "tests in the suite will pass when executed using the classes under test.";

	private static final String example = "java -jar randoop.jar genregressions --testclass=java.util.Collections "
			+ " --testclass=java.util.TreeSet";

    private static final List<String> notes;

    static {

	notes = new ArrayList<String>();
	notes.add("Randoop executes the code under test, with no mechanisms to protect your system from harm. If random execution of your code could have undesirable effects (e.g. deletion of files, opening network connections, etc.) make sure you execute Randoop in a sandbox machine.");
	notes.add("Randoop will only use methods from the classes that you specify for testing. If Randoop is not generating tests for a particular method, make sure that you are including classes for the types that the method requires. Otherwise, Randoop may fail to generate tests due to missing input parameters.");
	notes.add("Randoop is designed to be deterministic when the code under test is itself deterministic. This means that two runs of Randoop will generate the same tests. To get variation across runs, use the --randomseed option.");
	
    }


	private static Options options = new Options(GenInputsAbstract.class,
						     Log.class, ReflectionExecutor.class,
						     ForwardGenerator.class);

	public GenRegressions() {
		super(command, pitch, commandGrammar, where, summary, notes, input, output,
				example, options);
	}

	@Override
	public boolean handle(String[] args) throws RandoopTextuiException {

// 		RandoopSecurityManager randoopSecurityManager = new RandoopSecurityManager(
// 				RandoopSecurityManager.Status.OFF);
// 		System.setSecurityManager(randoopSecurityManager);

		try {
			String[] nonargs = options.parse(args);
			if (nonargs.length > 0)
				throw new ArgException("Unrecognized arguments: "
						+ Arrays.toString(nonargs));
		} catch (ArgException ae) {
			System.out
					.println("ERROR while parsing command-line arguments (will exit): "
							+ ae.getMessage());
			System.exit(-1);
		}

		// Modifies plans and testtime fields according to user arguments.
		System.out.println("TIME=" + timelimit + ",SEQS=" + inputlimit);
		Randomness.reset(randomseed);
				
		// Find classes to test.
		if (classlist == null && methodlist == null && testclass.size() == 0) {
			System.out.println("You must specify some classes or methods to test.");
			System.out.println("Use the --classlist, --testclass, or --methodlist options.");
			System.exit(1);
		}
		List<Class<?>> classes = findClassesFromArgs(options);

        List<StatementKind> model = 
        Reflection.getStatements(classes, new DefaultReflectionFilter(omitmethods));
		
		// Always add Object constructor (it's often useful).
		try {
			RConstructor cons = RConstructor.getRConstructor(Object.class.getConstructor());
			if (!model.contains(cons))
				model.add(cons);
		} catch (Exception e) {
			throw new BugInRandoopException(e); // Should never reach here!
		}
		
		if (methodlist != null) {
			Set<StatementKind> statements = new LinkedHashSet<StatementKind>();
			try {
				for (Member m : Reflection.loadMethodsAndCtorsFromFile(new File(methodlist))) {
					if (m instanceof Method) {
						statements.add(RMethod.getRMethod((Method)m));
					} else {
						assert m instanceof Constructor<?>;
						statements.add(RConstructor.getRConstructor((Constructor<?>)m));
					}
				}
			} catch (IOException e) {
				System.out.println("Error while reading method list file " + methodlist);
				System.exit(1);
			}
			for (StatementKind st : statements) {
				if (!model.contains(st))
					model.add(st);
			}
		}

		if (model.size() == 0) {
			Log.out.println("There are no methods to testclasses. Exiting.");
			System.exit(1);
		}
		System.out.println("Found " + model.size()
				+ " testable methods/constructors.");
		
		// For tracking coverage, we also need the superclasses of
		// the classes under test.
		List<Class<?>> coverageClassCandidates = new ArrayList<Class<?>>();
		if (coverage_instrumented_classes != null) {
		  File covClassesFile = new File(coverage_instrumented_classes);
		  try {
        coverageClassCandidates = Reflection.loadClassesFromFile(covClassesFile);
      } catch (IOException e) {
        throw new Error(e);
      }
		  for (Class<?> cls : coverageClassCandidates) {
		    assert Coverage.isInstrumented(cls) : cls.toString();
		    System.out.println("Will track branch coverage for " + cls);
		  }
		}

		ForwardGenerator explorer = new ForwardGenerator(
				 model, coverageClassCandidates, timelimit * 1000, inputlimit,
				new SequenceCollection(SeedSequences.objectsToSeeds(SeedSequences.primitiveSeeds)));
		
		// Generate inputs.
		explorer.explore();
		
		// Print branch coverage.
		System.out.println();
		//DecimalFormat format = new DecimalFormat("#.###");
		
		DataFlowInput dfin = initFrontierBranches(explorer);
		if (false) {
			for (Map.Entry<Branch, Set<Sequence>> e : dfin.frontierMap.entrySet()) {
				Branch b = e.getKey();
				try {
					// XXX Figure out a way to make sure this always works.
					// TODO: make sure you can always go from b.className to a class.
					String prefix = e.getKey().branch ? "T>" : "F>";
					System.out.println(Coverage.getMethodSource(Class.forName(b.className), b.lineNumber, prefix));
				} catch (ClassNotFoundException e1) {
					throw new RuntimeException(e1);
				}
			}
		}

		if (branchdir != null) { 
		  dfin.toParseableFile(branchdir);
		  //SerializationHelper.writeSerialized(branchdir, dfin);

		  if (coverage_output != null) {
		    BufferedWriter writer = null;
		    try {
		      writer = new BufferedWriter(new FileWriter(coverage_output));
		      // Touch all covered branches (they may have been reset during generation).
		      for (Branch br : explorer.stats.branchesCovered) {
		        Coverage.touch(br);
		      }
		      for (Class<?> cls : explorer.covClasses) {
		        for (String s : Coverage.getCoverageAnnotatedSource(cls)) {
		          writer.append(s);
		          writer.newLine();
		        }
		      }
		      writer.close();
		    } catch (IOException e) {
		      throw new Error(e);
		    }
		  }
		}

		if (dont_output_tests)
			return true;
		
		// Create JUnit files containing faults.
		System.out.println();
		System.out.print("Creating Junit tests ("
				+ explorer.getSelectedSequences().size() + " tests)...");
		List<ExecutableSequence> errorRevealingSequences = new ArrayList<ExecutableSequence>();
		for (ExecutableSequence p : explorer.getSelectedSequences()) {
			errorRevealingSequences.add(p);
		}

		JunitFileWriter jfw = new JunitFileWriter(junitclass, testsperfile);
		List<File> files = jfw.createJunitFiles(errorRevealingSequences);
		System.out.println();
		for (File f : files) {
			System.out.println("Created file: " + f.getAbsolutePath());
		}

		return true;
	}
	
	public static DataFlowInput initFrontierBranches(ForwardGenerator explorer) {
	  
	  // Maps a branch to a set of sequences that cover the branch.
	  Map<Branch, Set<Sequence>> frontierMap = new LinkedHashMap<Branch, Set<Sequence>>();
	   // Maps a branch to the method/constructor where the branch is located.
	  Map<Branch, StatementKind> statements = new LinkedHashMap<Branch, StatementKind>();

	  for (Class<?> cls : explorer.covClasses) {
	    
	    // Update frontierMap.
	    for (CoverageAtom ca : Coverage.getBranches(cls)) {
	      assert ca instanceof Branch;
	      Branch br = (Branch)ca;
	      
	      // Only put frontier branches that are inside methods or constructors.
	      if (Coverage.getMemberContaining(br) == null)
	        continue;
	      
        if (explorer.stats.branchesCovered.contains(br)) { // br was covered.
          if (!explorer.stats.branchesCovered.contains(br.getOppositeBranch())) {               
            // br was covered, but ~br was not covered.
            Set<Sequence> ss = explorer.branchesToCoveringSeqs.get(br);
            assert ss != null && !ss.isEmpty();
            frontierMap.put(br, ss);
          }
        } else { // br was not covered. 
          Branch oppBranch = br.getOppositeBranch();
          if (explorer.stats.branchesCovered.contains(oppBranch)) {
            // ~br was covered, but br was not covered.
            Set<Sequence> ss = explorer.branchesToCoveringSeqs.get(oppBranch);
            assert ss != null && !ss.isEmpty();
            frontierMap.put(oppBranch, ss);            
          }
        }
        
        // Update statements.
        Member member = Coverage.getMemberContaining(br);
        if (member == null)
          continue;
        if (member instanceof Method)
          statements.put(br, RMethod.getRMethod((Method)member));
        else {
          assert member instanceof Constructor<?>;
          statements.put(br, RConstructor.getRConstructor((Constructor<?>)member));
        }
	    }
	  }
	  return new DataFlowInput(frontierMap);
	}

    public static List<StatementKind> getStatementsThatCreateType(Class<?> type,
 		   List<StatementKind> statementsAsList) {
         ArrayList<StatementKind> retval = new ArrayList<StatementKind>();
         for (StatementKind info : statementsAsList) {
             Class<?> tc = info.getOutputType();
             if (tc == null)
                 continue;
             if (Reflection.canBeUsedAs(tc, type)) {
                 retval.add(info);
             }
         }
         return retval;
     }

     // Gets the classes associated with these statements.
     // A class is in the returned set if it is the class that
     // declares a method or constructor in this statement collection.
 	public static Set<Class<?>> getClasses(List<StatementKind> statementsAsList) {
 		Set<Class<?>> classes = new LinkedHashSet<Class<?>>();
 		for (StatementKind st : statementsAsList) {
 			if (st instanceof RMethod) {
 				RMethod mc = (RMethod)st;
 				classes.add(mc.getMethod().getDeclaringClass());
 			} else {
 				assert st instanceof RConstructor;
 				RConstructor mc = (RConstructor)st;
 				classes.add(mc.getConstructor().getDeclaringClass());
 			}
 		}
 		return classes;
 	}


 

}
