package randoop.main;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import randoop.DummyVisitor;
import randoop.ExecutableSequence;
import randoop.MSequence;
import randoop.MStatementCall;
import randoop.MVariable;
import randoop.PrimitiveOrStringOrNullDecl;
import randoop.Sequence;
import randoop.StatementKind;
import randoop.Variable;
import randoop.branchanalysis.DFResultsOneSeq;
import randoop.branchanalysis.DataFlowOutput;
import randoop.branchanalysis.DFResultsOneSeq.VariableInfo;
import randoop.util.Files;
import randoop.util.Reflection;
import randoop.util.SerializationHelper;
import cov.Coverage;
import cov.CoverageAtom;
import cov.Branch;

public class GenBranchDir {

  // Set in main method.
  private static List<Class<?>> covClasses;

  // Set in method.
  private static PrintStream out;

  /**
   * Usage:
   * 
   * GenBranchDir COVCLASSLIST DFOUTPUT
   * 
   * Where:
   * 
   * COVCLASSLIST is the list of coverage-instrumented classes in the program under test.
   *           
   * DFOUTPUT is a file containing a serialized DataFlowOutput object, the output
   *          of a run of the DataFlow program.
   */
  public static void main(String[] args) throws ClassNotFoundException, IOException {

    if (args.length != 2) throw new IllegalArgumentException("Expected two arguments.");
    String covClassesFileName = args[0];
    File covClassesFile = new File(covClassesFileName);
    String dfOutputFileName = args[1];

    // Read in the coverage-instrumented classes.
    // We need them in order to reset their coverage before executing
    // a sequence, so we can determine what coverage atoms the sequence covers.
    covClasses = new ArrayList<Class<?>>();
    for (String className : Files.readWhole(covClassesFile)) {
      covClasses.add(Reflection.classForName(className));
    }

    DataFlowOutput dfOut = (DataFlowOutput) SerializationHelper.readSerialized(dfOutputFileName);

    out = new PrintStream(new FileOutputStream("branchdir.txt", true));
    
    for (DFResultsOneSeq r : dfOut.results) {

      out.println("============================================================");
      out.println("START RECORD");
      out.println("BRANCH " + r.frontierBranch.toString() + "");
      out.println("SEQUENCE \\");
      out.println(r.sequence.toParseableString());
      out.println("END RECORD");
      out.println();
      out.println("As source code:");
      out.println(r.sequence.toCodeString());
      out.println("Variables: " + r.values);

      String lineSource =
        Coverage.getMethodSource(Class.forName(r.frontierBranch.getClassName()), r.frontierBranch.getLineNumber(), ">>");

      out.println(lineSource + "\n");
      
      if (true && r.values.size() != 1)
        continue;
      
      VariableInfo varinfo = new ArrayList<VariableInfo>(r.values).get(0);
      Variable var = varinfo.value;
      
      if (!var.getType().equals(int.class))
        continue;

      // Verify that sequence covers frontier branch.
      if (!covers(r.sequence, (Branch)r.frontierBranch))
        throw new RuntimeException("Sequence doesn't cover frontier branch");

      // Determine goal branch.
      assert r.frontierBranch instanceof Branch;
      Branch goalBranch = ((Branch)r.frontierBranch).getOppositeBranch();
      out.println("GOAL BRANCH (WILL TRY TO COVER): " + goalBranch);

      if (r.values.size() != 1) {
        out.println("CANNOT HANDLE VALUE LIST WITH SIZE != 1. SKIPPING THIS FRONTIER BRANCH.");
        continue;
      }

      if (var.getType().equals(int.class)) {
        boolean success = false;

        // First, try setting its value to a value compared to it during execution.
        for (String val : varinfo.branch_compares) {
          out.println("WILL TRY REPLACING " + var + " WITH VALUE " + val);
          int intval = Integer.parseInt(val);
          if (modifyAndCheck(r.sequence, var, intval, goalBranch)) {
            out.println("SUCCESS!");
            success = true;
            break;
          }
        }

        if (success) continue; // Move on to next frontier branch.

        // Try negating.
        {
          out.println("WILL TRY NEGATING " + var);
          StatementKind st = r.sequence.getStatementKind(var.getIndex());
          assert st instanceof PrimitiveOrStringOrNullDecl;
          PrimitiveOrStringOrNullDecl prim = (PrimitiveOrStringOrNullDecl)st;
          assert prim.getType().equals(int.class);
          int value = (Integer) prim.getValue();
          if (modifyAndCheck(r.sequence, var, -value, goalBranch)) {
            out.println("SUCCESS!");
            success = true;
          }
        }

        if (success) continue; // Move on to next frontier branch.

        // Try setting to 0.
        {
          out.println("WILL TRY SETTING TO ZERO " + var);
          if (modifyAndCheck(r.sequence, var, 0, goalBranch)) {
            out.println("SUCCESS!");
            success = true;
          }
        }

        if (success) continue; // Move on to next frontier branch.

        // Try adding 1.
        {
          out.println("WILL TRY ADDING 1 " + var);
          StatementKind st = r.sequence.getStatementKind(var.getIndex());
          assert st instanceof PrimitiveOrStringOrNullDecl;
          PrimitiveOrStringOrNullDecl prim = (PrimitiveOrStringOrNullDecl)st;
          assert prim.getType().equals(int.class);
          int value = (Integer) prim.getValue();
          if (modifyAndCheck(r.sequence, var, value + 1, goalBranch)) {
            out.println("SUCCESS!");
            success = true;
          }
        }

        if (success) continue; // Move on to next frontier branch.

        // Try adding 1.
        {
          out.println("WILL TRY SUBTRACTING 1 " + var);
          StatementKind st = r.sequence.getStatementKind(var.getIndex());
          assert st instanceof PrimitiveOrStringOrNullDecl;
          PrimitiveOrStringOrNullDecl prim = (PrimitiveOrStringOrNullDecl)st;
          assert prim.getType().equals(int.class);
          int value = (Integer) prim.getValue();
          if (modifyAndCheck(r.sequence, var, value - 1, goalBranch)) {
            out.println("SUCCESS!");
            success = true;
          }
        }
        
        if (success) continue;
        
        out.println("FAILURE");
      }
    }
  }

  // sequence: sequence to modify (goes through branch oppostive goalBranch)
  // 
  // Modifies sequence so that instead of "var = old_val", it has "var = val".
  // Executes sequence and checks if goalBranch is covered.
  // If so, returns true, else false.
  private static boolean modifyAndCheck(Sequence sequence, Variable var,
      int val, Branch goalBranch) {
    assert var.sequence == sequence;

    MSequence seq = sequence.toSlowSequence();
    MVariable mvar = seq.getVariable(var.getIndex());
    StatementKind st = new PrimitiveOrStringOrNullDecl(mvar.getType(), val);
    seq.statements.set(var.getIndex(), new MStatementCall(st, new ArrayList<MVariable>(), mvar));
    out.println("@@@" + seq.toCodeString());
    return covers(seq.toFastSequence(), goalBranch);
  }

  private static boolean covers(Sequence s, Branch br) {
    ExecutableSequence eseq = new ExecutableSequence(s);
    Set<Branch> coveredBranches = new LinkedHashSet<Branch>();
    Coverage.clearCoverage(covClasses);
    eseq.execute(new DummyVisitor());
    for (CoverageAtom ca : Coverage.getCoveredAtoms(covClasses)) {
      assert ca instanceof Branch;
      coveredBranches.add((Branch)ca);
    }
    if (coveredBranches.contains(br))
      return true;
    return false;
  }

}
