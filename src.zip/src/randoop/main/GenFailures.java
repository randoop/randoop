package randoop.main;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import randoop.ContractCheckingVisitor;
import randoop.DummyVisitor;
import randoop.ExecutableSequence;
import randoop.ExecutionVisitor;
import randoop.Expression;
import randoop.ForwardGenerator;
import randoop.Globals;
import randoop.JunitFileWriter;
import randoop.Observation;
import randoop.Sequence;
import randoop.SequenceGeneratorStats;
import randoop.StatementKind;
import randoop.experiments.ResultsWriter;
import randoop.util.DefaultReflectionFilter;
import randoop.util.Log;
import randoop.util.Randomness;
import randoop.util.Reflection;
import randoop.util.ReflectionExecutor;
import utilMDE.Option;
import utilMDE.Options;
import utilMDE.Options.ArgException;

/**
 * Randomly generates testclasses inputs and executes them. Test inputs that are
 * error-revealing are output as Junit tests.
 */
public class GenFailures extends GenInputsAbstract {

	private static final String command = "genfailures";

	private static final String pitch = "Attempts to generate contract-violating unit tests for a set of classes.";

	private static final String commandGrammar = "genfailures OPTIONS";

	private static final String where = "At least one class is specified via `--testclass' or `--classlist'.";

	private static final String summary = "Attempts to generate JUnit tests that violate an API contract. "
		+ "Randoop generates tests using feedback-directed random test generation. "
		+ "If no tests are generated that violate any contracts, this command will not "
		+ "output any tests (see `genregressions' command if you want to generate unit "
	    + "tests that do not violate contracts).";

	private static final String input = "One or more names of classes to test. A class to test can be specified "
		+ "via the `--testclass=<CLASSNAME>' or `--classlist=<FILENAME>' options.";

	private static final String output = "A JUnit test suite (as one or more Java source files). The "
		+ "tests in the suite will fail when executed using the classes under test.";

	private static final String example = "java -jar randoop.jar genfailures --testclass=java.util.Collections "
		+ " --testclass=java.util.TreeSet";

    private static final List<String> notes;

    static {

	notes = new ArrayList<String>();
	notes.add("Randoop executes the code under test, with no mechanisms to protect your system from harm. If random execution of your code could have undesirable effects (e.g. deletion of files, opening network connections, etc.) make sure you execute Randoop in a sandbox machine.");
	notes.add("Randoop will only use methods from the classes that you specify for testing. If Randoop is not generating tests for a particular method, make sure that you are including classes for the types that the method requires. Otherwise, Randoop may fail to generate tests due to missing input parameters.");
	notes.add("Randoop is designed to be deterministic when the code under test is itself deterministic. This means that two runs of Randoop on deterministic code will generate the same tests. To get variation across runs, use the --randomseed option.");
	
    }
	
	@Option("Specify the fully-qualified name of a checker class to install.")
	public static List<String> checkerclass = new ArrayList<String>();

	private static Options options = new Options(Globals.class, GenInputsAbstract.class, GenFailures.class, Log.class, ReflectionExecutor.class, SequenceGeneratorStats.class); 

	public GenFailures() {
		super(command, pitch, commandGrammar, where, summary, notes, input, output, example, options);
	}

	@Override
	public boolean handle(String[] args) throws RandoopTextuiException {

// 		RandoopSecurityManager randoopSecurityManager =
// 		    new RandoopSecurityManager(RandoopSecurityManager.Status.OFF);
// 		System.setSecurityManager(randoopSecurityManager);
		
		try {
		  String[] nonargs = options.parse(args);
		  if (nonargs.length > 0) throw new ArgException("Unrecognized arguments: " + Arrays.toString(nonargs));
		} catch (ArgException ae) {
			System.out.println("ERROR while parsing command-line arguments (will exit): " + ae.getMessage());
		  System.exit (-1);
		}

		// Modifies plans and testtime fields according to user arguments.
		System.out.println("TIME=" + timelimit + ",SEQS=" + inputlimit);
		Randomness.reset(randomseed);

		// Find classes to test.
		List<Class<?>> classes = findClassesFromArgs(options);
		
		// Find any user-specified checkers.
		List<Expression> checkersFromArgs = findCheckersFromArgs(options);
		
        List<StatementKind> model = 
        Reflection.getStatements(classes, new DefaultReflectionFilter(omitmethods));
		
		if (model.size() == 0) {
			Log.out.println("There are no methods to testclasses. Exiting.");
			System.exit(1);
		}
		System.out.println("Found " + model.size() + " testable methods/constructors.");
		
		ExecutionVisitor faultFinder;
		if (dontcheckcontracts) {
			faultFinder = new DummyVisitor();
		} else {
			// Create list of properties to check.
			List<Expression> finalCheckers = new ArrayList<Expression>();
			finalCheckers.addAll(ContractCheckingVisitor.defaultCheckers());
			finalCheckers.addAll(checkersFromArgs);

			System.out.println("Installed property checkers:");
			for (Expression c : finalCheckers) {
				System.out.println(c.getClass().toString());
			}
			
			faultFinder = new ContractCheckingVisitor();
		}
		
		ForwardGenerator explorer = new ForwardGenerator(model,
				null, timelimit * 1000, inputlimit, null);

		// Generate inputs.
		explorer.explore();

		if (branchdir != null) {
			throw new RuntimeException("not implemented.");
		}

		if (Globals.randooptestrun) {
			System.out.println();
			System.out.println("Checking that explorer.allSequences contains no repeated sequences.");
			List<String> stringList = new ArrayList<String>();
			List<Sequence> componentList = new ArrayList<Sequence>(explorer
					.allSequences());
			for (int i = 0; i < componentList.size(); i++) {
				Sequence c = componentList.get(i);
				String s = c.toCodeString();
				if (stringList.contains(s)) {
					int j = stringList.indexOf(s);
					Sequence other = componentList.get(j);
					System.out.println(">>" + c.toCodeString());
					System.out.println("<<" + other.toCodeString());
					System.exit(1);
				} else {
					stringList.add(s);
				}
			}
		}

		if (!dontexecute) {
			// Create Junit files containing faults.
			System.out.println();
			System.out.print("Creating Junit tests with errors (faults=" + explorer.getSelectedSequences().size() + ")...");
			List<ExecutableSequence> errorRevealingSequences = new ArrayList<ExecutableSequence>();
			for (ExecutableSequence p : explorer.getSelectedSequences()) {
				errorRevealingSequences.add(p);
			}

			JunitFileWriter jfw = new JunitFileWriter(junitclass, testsperfile);
			List<File> files = jfw.createJunitFiles(errorRevealingSequences);
			System.out.println();
			for (File f : files) {
				System.out.println("Created file: " + f.getAbsolutePath());
			}
		}

		// If we're running the randoop randoop.experiments, output results.
		if (experiment != null) {
			System.out.print("Saving experiment statistics: " + experiment
					+ "...");
			File expFile = new File(experiment);
			FileWriter expWriter;
			try {
				expWriter = new FileWriter(expFile);
				expWriter.write(ResultsWriter.faultsSummary(timelimit, explorer,
						model));
				expWriter.flush();
				expWriter.close();
			} catch (IOException e) {
				// TODO this exception will propagate to top-level. bad.
				throw new RuntimeException(e);
			}
			System.out.println("done.");
		}

		System.out.println("done.");
		return true;
	}

	private List<Expression> findCheckersFromArgs(Options printUsageTo) {

		List<Class<?>> checkerClasses = null;
		try {
			checkerClasses = Reflection.loadClassesFromList(checkerclass);
		} catch (Exception e) {
			System.out.println("ERROR while reading list of checker classes:" + e.getMessage());
			System.exit(1);
		}
		
		List<Expression> ret = new ArrayList<Expression>();
		
		for (Class<?> c : checkerClasses) {
			
			if (!Observation.class.isAssignableFrom(c)) {
				System.out.println("ERROR while accessing checker class: " + c.toString());
				System.out.println("does not implement");
				System.out.println(Observation.class.toString());
				System.exit(1);
			}
			
			Constructor<Expression> parameterlessCons = null;
			try {
				parameterlessCons = (Constructor<Expression>) c.getConstructor();
			} catch (SecurityException e) {
				System.out.println("ERROR (SecurityException) while accessing constructor for checker class" + c.toString() + ":" + e.getMessage());
				System.exit(1);
			} catch (NoSuchMethodException e) {
				System.out.println("ERROR (NoSuchMethodException) while accessing constructor for checker class" + c.toString() + ":" + e.getMessage());
				System.out.println();
				System.out.println("NOTE that a checker class must provide a public constructor that takes zero arguments.");
				System.exit(1);
			}
			
			Expression newChecker = null;
			try {
				newChecker = parameterlessCons.newInstance();
			} catch (Exception e) {
				System.out.println("ERROR while invoking constructor of checker class " + c.toString() + ":" + e.getMessage());
				System.exit(1);
			}
			
			ret.add(newChecker);
			
		}
		return ret;
	}

}
