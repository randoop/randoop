package randoop;

/**
 * Means that the execution of a statement threw an exception.
 */
public class ExceptionalExecution implements ExecutionOutcome {

    private final Throwable exception;
    private final long executionTime; 
    
    public ExceptionalExecution(Throwable exception, long executionTime) {
        if (exception == null) throw new IllegalArgumentException();
        this.exception = exception;
        this.executionTime = executionTime;
    }
    
    public Throwable getException() {
        return this.exception;
    }
    
    /** Warning: this method calls toString() of code under test, which may have
     * arbitrary behavior. We use this method in randoop.test.SequenceTests.
     */
    @Override
    public String toString() {
        StringBuilder b = new StringBuilder();
        b.append("// <StatementExecutionResult object=<undefined>");
        b.append(", exception=" + toStringSafe(exception));
        b.append(">;");
        return b.toString();
    }

    private static String toStringSafe(Throwable o) {
        try {
            return o.toString();
        } catch (Exception e) {
            // do nothing.
        }
        return "<undefined>";
    }
    
    public long getExecutionTime() {
        return executionTime;
    }
}
