package randoop;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import randoop.util.CollectionsExt;
import randoop.util.ReflectionCode;
import randoop.util.ReflectionExecutor;
import randoop.util.Timer;
import utilMDE.Pair;


/**
 * An execution visitor that checks a set of contracts (specified in a
 * ContractCheckingVisitor) on the values created by the sequence. It does this only after
 * the last statement has been executed. For each contract violation, the
 * visitor adds a ContractFailureDecoration to the corresponding index in the
 * sequence.
 */
public final class ContractCheckingVisitor implements ExecutionVisitor {

    // For timing time spent checking contracts.
    private static final Timer contractChecksTimer = new Timer();

    private final Set<Class<?>> badExceptions;
    private final List<Expression> behaviorsToCheck;

    @SuppressWarnings("unchecked")
	public ContractCheckingVisitor() {
    	this(Collections.EMPTY_LIST);
    }
    
    public ContractCheckingVisitor(List<Expression> toCheck) {
        if (toCheck == null) throw new IllegalArgumentException("null not allowed");
        this.behaviorsToCheck= CollectionsExt.roCopyList(toCheck);//copy
        this.badExceptions = new LinkedHashSet<Class<?>>();
        badExceptions.add(StackOverflowError.class); //this is often a bug.
        badExceptions.add(OutOfMemoryError.class);   //this is often a bug.
    }

    /**
     * Returns whether the exception is considered bad: i.e., its occurrence signals a bug. 
     */
    public boolean isBadException(Class<? extends Throwable> exc) {
        return badExceptions.contains(exc);
    }
    
    public static List<Expression> defaultCheckers(){
       Expression b1 = new EqualsToItself();
       return Arrays.<Expression>asList(b1);
    }

    public static List<Expression> allCheckers(){
        return Arrays.<Expression>asList(
                new EqualsHashcodeContractViolated(),
                new EqualsToItself(), 
                new EqualsNotSymmetric(),
                new EqualsNotTransitive(),
                new EqualsToNull()
                );
    }
    
    /**
     * Returns the total amount of testtime spent checking contracts,
     * accumulated across all contract checkers (for performance
     * measurements).
     */
    public static long timeSpentCheckingContracts() {
        assert !contractChecksTimer.isRunning();
        return contractChecksTimer.getTimeElapsedMillis();
    }

    /**
     * Checks all known contracts for all permutations of all objects in the provided array.
     * Returns a list of Decorations, where each checker represents
     * a behavior that the objects exhibited (the array of objects is also returned). 
     */
    public List<Pair<Pair<Expression,Object>, Object[]>> checkForFaults(Object[] objectsToCheck) {
        assert !contractChecksTimer.isRunning();
        contractChecksTimer.startTiming();

        List<Pair<Pair<Expression,Object>, Object[]>> ret = new ArrayList<Pair<Pair<Expression,Object>, Object[]>>(behaviorsToCheck.size());
        int maxArity= findMaxCheckerArity();
        Map<Integer, Set<Object[]>> objGroupsPerArity= CollectionsExt.createPerArityGroups(objectsToCheck, maxArity);
        for (Expression checker : behaviorsToCheck){
            for (Object[] objs : objGroupsPerArity.get(checker.getArity())) {
            	Pair<Expression,Object> newChecker = checkFaults(checker, objs);
                if (newChecker != null){
                    ret.add(new Pair<Pair<Expression,Object>, Object[]>(newChecker, objs));
                }
            }
        }
        contractChecksTimer.stopTiming();
        return ret;
    }

    //We need to execute this code in a safe way - it can be arbitrary code, with infinite loops etc.
    public static Pair<Expression,Object> checkFaults(final Expression checker, final Object[] objs) {
        ReflectionCode refl = new ReflectionCode(){
            private Object result;
            private Throwable exception;
            @Override public Throwable getExceptionThrown() { return exception; }
            @Override public Object getReturnVariable() { return result; }
            @Override protected void runReflectionCodeRaw() {
                try {
                   result = checker.evaluate(objs);
                } catch (Throwable e) {
                    exception = e;
                } finally {
                    setRunAlready();
                }                        
            }
        };
        Throwable t = ReflectionExecutor.executeReflectionCode(refl, System.out);
        if (t != null || refl.getExceptionThrown() != null){
            return new Pair<Expression,Object>(checker, refl.getReturnVariable());
        }
        return new Pair<Expression,Object>(checker, refl.getExceptionThrown().toString());
    }

    private int findMaxCheckerArity() {
        int max= 0;
        for (Expression bh : behaviorsToCheck) {
            max= Math.max(max, bh.getArity());
        }
        return max;
    }
    
    public void visitBefore(ExecutableSequence sequence, int i) {
        // no body.
    }

    public boolean visitAfter(ExecutableSequence sequence, int i) {

    	// We check contracts only after the last statement is executed.
    	if (i < sequence.sequence.size() - 1) 
    		return true;

    	if (sequence.getResult(i) instanceof ExceptionalExecution) {
    		ExceptionalExecution e = (ExceptionalExecution)sequence.getResult(i);
    		
    		if (isBadException(e.getException().getClass())) {
    			sequence.addDecoration(i, new ExceptionObservation(e.getException()));
    		}
    		return true;
    	}
    	
    	assert sequence.getResult(i) instanceof NormalExecution;
    	
    	// Check for object faults.
    	
    	Set<ExpressionEqualsValue> violations = new LinkedHashSet<ExpressionEqualsValue>();
        Object[] allRuntimeObjects = getAllRuntimeObjects(sequence);
        
        for (Pair<Pair<Expression,Object>, Object[]> faultAndObjs : checkForFaults(allRuntimeObjects)) {
            List<Variable> corresponsingVariables= findCorresponsingVariables(faultAndObjs.b, sequence);
            violations.add(new ExpressionEqualsValue(faultAndObjs.a.a.getClass(), corresponsingVariables, faultAndObjs.a.b));
        }        
    	
    	sequence.addDecorations(i, violations);

    	return true;
    }

    //XXX BOGUS HACK Adam to fix!
    //This is bad because duplicates code and computation.
    /*
     * Finds values that correspond to the runtime objects.
     */
    private List<Variable> findCorresponsingVariables(Object[] objs, ExecutableSequence sequence) {
        List<Variable> values = sequence.sequence.getLastStatementVariables();
        List<Variable> result= new ArrayList<Variable>(objs.length);
        for (int i = 0; i < objs.length; i++) {
            for (int j = 0; j < values.size(); j++) {
                Variable v= values.get(j);
                int index = v.getIndex();
                if (!(sequence.getResult(index) instanceof NormalExecution))
                    continue;
                NormalExecution e = (NormalExecution)sequence.getResult(index);
                if (e.getRuntimeVariable() == objs[i]){//identity is the right thing here!
                    result.add(v);
                    break;//found the guy, stop looking
                }
            }
        }
        return result;
    }

    //XXX almost a dup of code in ObjectContractViolation
    private Object[] getAllRuntimeObjects(ExecutableSequence sequence){
        //be careful to not execute any code on the stored objects. ArrayList executes code on calls 
        //like toString, hashCode, equals etc. Do not call those.
        List<Object> list= new ArrayList<Object>();
        for (Variable v : sequence.sequence.getLastStatementVariables()) {
            int i = v.getIndex();
            if (!(sequence.getResult(i) instanceof NormalExecution))
                continue;
            NormalExecution e = (NormalExecution)sequence.getResult(i);
            Object value = e.getRuntimeVariable();
            if (value != null){
                if (! CollectionsExt.containsIdentical(list, value))
                    list.add(value);
            }
        }
        return list.toArray();
    }

}
