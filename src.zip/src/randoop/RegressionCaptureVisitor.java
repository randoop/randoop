package randoop;


/**
 * An execution visitor that records regression observations on the values
 * created by the sequence. It does this only after the last statement has been
 * executed. For each observation, the visitor adds a RegressionDecoration to
 * the last index in the sequence.
 * 
 * NOTE: objects of this class are immutable. They can be shared.
 */
public final class RegressionCaptureVisitor implements ExecutionVisitor {

	public RegressionCaptureVisitor() {

	}

	public boolean visitAfter(ExecutableSequence sequence, int i) {
		return true;
	}

	public void visitBefore(ExecutableSequence sequence, int i) {
		return;
	}

//    private final PurityInfo purityInfo;
//    
//    public RegressionCaptureVisitor(PurityInfo observerInfo) {
//        this.purityInfo = observerInfo;
//    }
//
//    public PurityInfo getPurityInfo() {
//        return this.purityInfo;
//    }
//    
//    public void visitBefore(ExecutableSequence sequence, int idx) {
//        // empty body.
//    }
//
//    public boolean visitAfter(ExecutableSequence s, int idx) {
//        
//        //we're only interested in statements at the end
//        if (idx < (s.sequence.size()-1))
//            return true;
//
//        // Capture observations for each value created.
//        // Recall there are as many values as statements in the sequence.
//        for (int i = 0; i < s.sequence.size() ; i++) {
//        	
//        	// If statement did not execute normally, don't capture behavior.
//        	// TODO capture behavior about the thrown exception. 
//            if (!(s.getResult(i) instanceof NormalExecution))
//                continue;
//            
//            NormalExecution e = (NormalExecution)s.getResult(i);
//            
//            // If value is like x in "int x = 3" don't capture observations (nothing interesting).  
//            if (s.sequence.getStatement(i) instanceof PrimitiveOrStringOrNullDecl) 
//                continue;
//
//            // If value's type is void (i.e. its statement is a void-return method call), don't
//            // capture observations (nothing interesting).
//            Class<?> tc = s.sequence.getStatement(i).getOutputType();
//            if (void.class.equals(tc))
//                continue; // no return value.
//            
//            Object o = e.getRuntimeVariable();
//            Class<?> c = tc;
//            if (o != null && !Reflection.canBeUsedAs(o.getClass(), c)) {
//                // This can happen if a methodCallInfo.returnIndexCast == true
//                // but at runtime, the method actually returns a different
//                // class.
//                continue;
//            }
//            
//            Variable valAtIdx = s.sequence.getVariable(i);
//            
//            if (o == null) {
//                s.addDecoration(idx, new NullObservation(s, valAtIdx));
//            } else if (PrimitiveOrStringObservation.isPrimitiveOrString(o)) {
//                s.addDecoration(idx, new PrimitiveOrStringObservation(s, valAtIdx));
//            } else {
//                for (Method m : purityInfo.getObservers(c)) {
//                    s.addDecoration(idx, new ObserverMethodObservation(m, s, valAtIdx));        
//                }
//            }
//        }
//
//        if (s.getResult(idx) instanceof ExceptionalExecution) {
//            ExceptionalExecution e = (ExceptionalExecution)s.getResult(idx);
//            s.addDecoration(idx, new ExceptionDecoration(e.getException(), s, idx));
//        }
//        return true;
//    }
//    
//    private static void checkIfObserver(Method m) {
//        if (m == null)
//            throw new IllegalArgumentException("method cannot be null.");
//        if (!(m.getReturnType().isPrimitive() || m.getReturnType().equals(String.class)))
//            throw new IllegalArgumentException("method must return a primitive or String: " + m);
//        if (m.getParameterTypes().length > 0)
//            throw new IllegalArgumentException("method must take zero parameters:" + m);
//        if (! Modifier.isPublic(m.getModifiers()))
//            throw new IllegalArgumentException("Non-public method : " + m);
//        if (! PurityInfo.mayBeObserver(m))
//            throw new IllegalStateException("Sanity check failed. This state is insane.");
//    }
//
//    private static void checkOk(Object receiverObj, Method m) {
//        if (receiverObj == null)
//            throw new IllegalArgumentException("receiver object cannot be null.");
//
//        if (!Reflection.canBeUsedAs(receiverObj.getClass(),
//                m.getDeclaringClass()))
//            throw new IllegalArgumentException("class mismatch:" + receiverObj.getClass() + " vs " + m.getDeclaringClass());
//    }
//
//    // Postcondition: the return value is a NormalExecution or an ExceptionalExecution.
//    private static ExecutionOutcome execute(final Method method2, final Object receiver) {
//        MethodReflectionCode code = new MethodReflectionCode(method2, receiver, new Object[0]);
//        long startTime = System.currentTimeMillis();
//        Throwable exceptionMaybe = ReflectionExecutor.executeReflectionCode(code, Globals.blackHole);
//        long totalTime = System.currentTimeMillis() - startTime;
//        if (exceptionMaybe == null) {
//            // At one point, we asserted that code.getReturnVariable() was non-null here.
//            return new NormalExecution(code.getReturnVariable(), totalTime);
//        } else {
//            return new ExceptionalExecution(exceptionMaybe, totalTime);
//        }
//    }
//    
//
//    public MatchResult replay(Execution execution) { if (execution == null) throw new IllegalArgumentException("execution cannot be null.");
//        
//        if (expectedResult instanceof NormalExecution) {
//            NormalExecution e = (NormalExecution)sequence.getResult(value.getIndex());
//            Object newReceiver = e.getRuntimeVariable();
//            if (newReceiver == null)
//                return MatchResult.failure("receiver was null");
//            if (!newReceiver.getClass().equals(receiverClass))
//                return MatchResult.failure("receiver class was " + newReceiver.getClass().getName() + " but was expected to be " + receiverClass.getName());
//            return matches(newReceiver);
//            
//            
//        } else {
//            assert expectedResult instanceof ExceptionalExecution);
//            // trivially, because then this observation is meaningless, therefore not required to be reproducible.   
//            return MatchResult.success();
//        }
//        
//    }
//    
//    private MatchResult matches(Object rcvr) {
//        checkOk(rcvr, this.method);
//        
//        if (expectedResult instanceof NormalExecution) {
//            NormalExecution expected = (NormalExecution)sequence.getResult(value.getIndex());
//        
//            ExecutionOutcome newReturnVariable = execute(this.method, rcvr);
//            if (newReturnVariable instanceof NormalExecution) {
//                NormalExecution e = (NormalExecution)newReturnVariable;
//                boolean match = Util.equalsWithNull(e.getRuntimeVariable(), expected.getRuntimeVariable());
//                if (match)
//                    return MatchResult.success();
//                else
//                    return MatchResult.failure(this.method.getName() +
//                            "() OLD VALUE WAS " + expected.getRuntimeVariable() +
//                            " BUT NEW VALUE IS " + e.getRuntimeVariable());
//                
//            } else {
//                assert expectedResult instanceof ExceptionalExecution);
//                return MatchResult.failure(this.method.getName() +
//                        "() OLD VALUE WAS " + expected.getRuntimeVariable() +
//                        " BUT THREW EXCEPTION IN NEW EXECUTION");
//            }
//            
//        } else {
//            assert expectedResult instanceof ExceptionalExecution);
//            return MatchResult.success(); // because the observation is meaningless.
//        }
//    }
//
//  

}