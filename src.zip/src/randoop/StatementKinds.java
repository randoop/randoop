package randoop;

public class StatementKinds {

  public static StatementKind parse(String str) {
    if (str == null || str.length() == 0)
      throw new IllegalArgumentException("invalid string: " + str);

    
    // <id> : <description>
    int colonIdx = str.indexOf(':');
    String id = str.substring(0, colonIdx).trim();
    String descr = str.substring(colonIdx + 1).trim();

    // Call appropriate parsing method.
    if (id.equals(PrimitiveOrStringOrNullDecl.ID)) {
      return PrimitiveOrStringOrNullDecl.parse(descr);
    } else if (id.equals(RMethod.ID)) {
      return RMethod.parse(descr);
    } else if (id.equals(RConstructor.ID)) {
      return RConstructor.parse(descr);
    } else if (id.equals(ArrayDeclaration.ID)) {
      return ArrayDeclaration.parse(descr);
    } else if (id.equals(DummyStatement.ID)) {
      return DummyStatement.parse(descr);
    } else {
      throw new Error();
    }
  }

  public static String getId(StatementKind st) {
    if (st == null) throw new IllegalArgumentException("st cannot be null.");
    if (st instanceof PrimitiveOrStringOrNullDecl)
      return PrimitiveOrStringOrNullDecl.ID;
    if (st instanceof RMethod)
      return RMethod.ID;
    if (st instanceof RConstructor)
      return RConstructor.ID;
    if (st instanceof ArrayDeclaration)
      return ArrayDeclaration.ID;
    if (st instanceof DummyStatement)
      return DummyStatement.ID;
    throw new Error();
  }

}
