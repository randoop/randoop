package randoop;

import java.io.*;
import java.util.*;

import randoop.util.*;

/**
 * Outputs a collection of sequences as Java files, using the JUnit framework, with one method per sequence.
 */
public class JunitFileWriter {
    /**
     * The class of the main JUnit suite, and the prefix of the subsuite names.
     */
    private final String junitDriverClassName;

    /**
     * The package name of the main JUnit suite
     */
    private final String packageName;
    
    //A hack to print the test number when running the tests
    //Usefull for purity experiments
    public static boolean with_test_number = false; 
    //A hack to enable purity analysis to stop tests
    //after a timeout
    public static boolean with_test_timeout = false;
    
    public static boolean includeParseableString = false;
    
    private int testsPerFile;
    /**
     * The directory to put generated JUnit files into (will not be created if it doesn't already exist),
     * or null for the current working directory.
     */
    private String outputDirectoryName = null;

    private Map<String, List<List<ExecutableSequence>>> createdSequencesAndClasses = new LinkedHashMap<String, List<List<ExecutableSequence>>>();
    
    public JunitFileWriter(String junitDriverClassName, String packageName, int testsPerFile) {
        this.junitDriverClassName = junitDriverClassName;
        this.packageName = packageName;
        this.testsPerFile = testsPerFile;
    }
    
    public JunitFileWriter(String junitClassName, int testsPerFile) {
        this(junitClassName, "",testsPerFile);
    }
    
    /**
     * Sets the directory name for the generated files (or null for the current working directory).
     * @param outputDirectoryName
     */
    public void setOutputDirectoryName(String outputDirectoryName) {
        this.outputDirectoryName = outputDirectoryName;
    }

    /** Creates Junit tests for the faults.
    * Output is a set of .java files.
    */
    public <D extends Observation> List<File> createJunitTestFiles(List<ExecutableSequence> sequences, String junitTestsClassName) {
        if (sequences.size() == 0) {
            System.out.println("No sequences given to createJunitFiles. No Junit class created.");
            return new ArrayList<File>();
        }
        List<File> ret = new ArrayList<File>();
        List<List<ExecutableSequence>> subSuites = CollectionsExt.<ExecutableSequence>chunkUp(new ArrayList<ExecutableSequence> (sequences), testsPerFile);
        for (int i = 0 ; i < subSuites.size() ; i++) {
            ret.add(writeSubSuite(subSuites.get(i), i, junitTestsClassName));            
        }
        createdSequencesAndClasses.put(junitTestsClassName, subSuites);
        return ret;
    }
    
    /** Creates Junit tests for the faults.
     * Output is a set of .java files.
     * 
     * the default junit class name is the driver class name + index
     */
    public<D extends Observation> List<File> createJunitTestFiles(List<ExecutableSequence> sequences) {
        return createJunitTestFiles(sequences, junitDriverClassName);
    }
    
    /** create both the test files and the drivers for convinience **/
    public <D extends Observation> List<File> createJunitFiles(List<ExecutableSequence> sequences, List<Class<?>> allClasses) {
    	List<File> ret = new ArrayList<File>();
        ret.addAll(createJunitTestFiles(sequences));
        ret.add(writeDriverFile(allClasses));
        return ret;
    }
    
    /** create both the test files and the drivers for convinience **/
    public <D extends Observation> List<File> createJunitFiles(List<ExecutableSequence> sequences) {
    	List<File> ret = new ArrayList<File>();
        ret.addAll(createJunitTestFiles(sequences));
        ret.add(writeDriverFile());
        return ret;
    }
    

    private File writeSubSuite(List<ExecutableSequence> sequencesForOneFile, int i, String junitTestsClassName) {
        String className = junitTestsClassName + i;
        File file = createTextOutputFile(className + ".java");
        PrintStream out = createTextOutputStream(file);

        try{
            outputPackageName(out);
            out.println("import junit.framework.*;");
            if(with_test_timeout)  out.println("import " +TimeOutException.class.getCanonicalName()+ ";");
            out.println("public class " + className + " extends TestCase {");
    
            if(with_test_timeout) {
                out.println("@Override");
                out.println("protected void setUp() {");
                out.println(" testStartXXX();");   
                out.println("}");
                out.println("public void testStartXXX() {}");
            }
            
            hack(out);
            writeMain(out, className);

            int testCounter = 0;
            for (ExecutableSequence fault : sequencesForOneFile) {
                if (includeParseableString) {
                    out.println("/*");
                    out.println(fault.sequence.toString());
                    out.println("*/");
                }
                out.println("public void testclasses" + testCounter++ + "() throws Throwable {");
                if(with_test_number) out.println("System.out.println(\"* Test "+(testCounter-1)+" *\");");
                if(with_test_timeout) out.println("try {");
                out.println(fault.toCodeString());
                if(with_test_timeout)  {
                    out.println("} catch(TimeOutException e) {");
                    out.println(" System.out.println(\"*****Test stopped*****\");");
                    out.println(" return;}");
                }
                out.println("} /* ENDMETHOD */");
                out.println();
            }
            out.println("}");
        } finally {
            if (out != null)
                out.close();
        }
        
        return file;
    }

    private void writeMain(PrintStream out, String className) {
        out.println("public static void main(String[] args) {");
        out.println("    junit.textui.TestRunner.run(" + className + ".class);");
        out.println("}");
    }

    private void outputPackageName(PrintStream out) {
        boolean isDefaultPackage= packageName.length() == 0;
        if (!isDefaultPackage)
            out.println("package " + packageName + ";");
    }

    // HACK HACK HACK! We're going to hardcode a checkSpec for each
    // object after every method call. The checkSpec method checks
    // the set of unary contracts that we currently have).
    private void hack(PrintStream out) {
        out.println("public void checkSpec(Object o) {");
        out.println("  if (o == null) throw new RuntimeException(\"null reference passed.\");");
        out.println("  o.toString();");
        out.println("  o.hashCode();");
        out.println("  if (o.equals(o) == false) throw new RuntimeException(\"violated o.equals(o)==true\");");
        out.println("}");
    }

    public File writeDriverFile() {
        return writeDriverFile(Collections.<Class<?>>emptyList(), junitDriverClassName);
    }
    
    public File writeDriverFile(List<Class<?>> allClasses) {
        return writeDriverFile(allClasses, junitDriverClassName);
    }
    /** Creates Junit tests for the faults.
     * Output is a set of .java files.
     * 
     * @param allClasses List of all classes of interest (this is a workaround for emma missing problem: 
     * we want to compute coverage over all classes, not just those that happened to have been touched during execution.
     * Otherwise, a bad suite can report good coverage.
     * The trick is to insert code that will load all those classes; 
     */    
    public File writeDriverFile(List<Class<?>> allClasses, String driverClassName) {
    	File file = new File(driverClassName + ".java");
        PrintStream out = createTextOutputStream(file);
        try {
            outputPackageName(out);
            out.println("import junit.framework.*;");
            out.println("import junit.textui.*;");
            out.println("");
            out.println("public class " + driverClassName + " extends TestCase {");
            out.println("");
            out.println("  public static void main(String[] args) {");
            out.println("    TestRunner runner = new TestRunner();");
            out.println("    TestResult result = runner.doRun(suite(), false);");
            out.println("    if (! result.wasSuccessful()) {");
            out.println("      System.exit(1);");
            out.println("    }");
            out.println("  }");
            out.println("");
            out.println("  public " + driverClassName + "(String name) {");
            out.println("    super(name);");
            out.println("  }");
            out.println("");
            out.println("  public static Test suite() {");
            out.println("    TestSuite result = new TestSuite();");
            for(String junitTestsClassName : createdSequencesAndClasses.keySet()) {
                int numSubSuites = createdSequencesAndClasses.get(junitTestsClassName).size();
                for (int i = 0; i < numSubSuites; i++)
                    out.println("    result.addTest(new TestSuite(" + junitTestsClassName + i
                        + ".class));");
            }
            out.println("    return result;");
            out.println("  }");
            printClassLoadingCode(allClasses, out);
            out.println("");
            out.println("}");
        } finally {
            if (out != null)
                out.close();
        }
        return file;
    }
    
    
    private void printClassLoadingCode(List<Class<?>> allClasses, PrintStream out) {
        if (allClasses.isEmpty()) 
            return;
        out.println("static { //workaround for emma problem. We must load all classes to see more accurate coverage numbers");
        out.println("  Class<?>[] c={");
        for (Class<?> c : allClasses) {
            out.println("    " + c.getCanonicalName() + ".class,");
        }
        out.println("  };");
        out.println("}");
    }

    private File createTextOutputFile(String fileName) {
        if (outputDirectoryName != null)
            new File(outputDirectoryName).mkdirs();
        return new File(outputDirectoryName, fileName);
    }
    

    private PrintStream createTextOutputStream(File file) {
        try {
            return new PrintStream(file);
        } catch (IOException e) {
            Log.out.println("Exception thrown while creating text print stream:" + file.getName());
            e.printStackTrace();
            System.exit(1);
            return null;//make compiler happy
        }
    }
}
