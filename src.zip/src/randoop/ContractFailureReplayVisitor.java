package randoop;


/**
 * A visitor that expects a sequence with (perhaps) contract-failure decorations.
 * For each such decoration, it replays the behavior and throws an exception
 * if it encounters a decoration that doesn't replay. 
 *
 */
public final class ContractFailureReplayVisitor implements ExecutionVisitor {

	public boolean visitAfter(ExecutableSequence sequence, int i) {
		// TODO Auto-generated method stub
		throw new RuntimeException("not implemented");
	}

	public void visitBefore(ExecutableSequence sequence, int i) {
		// TODO Auto-generated method stub
		throw new RuntimeException("not implemented");
	}

//    public boolean visitAfter(ExecutableSequence sequence, int i) {
//        for (Decoration d : sequence.getDecorations(i, ContractFailureDecoration.class)) {
//        	MatchResult result = d.replay(sequence, );
//            if (!result.isSuccessful())
//                throw new ReplayFailureException(result.getErrorMessage(), d);
//        }
//        return true;
//    }
//
//    public void visitBefore(ExecutableSequence sequence, int i) {
//        // empty body.
//    }
}
