package randoop;

public interface StateMatcher {

    public boolean add(Object object);

    public int size();

}
