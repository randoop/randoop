package randoop;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import cov.Coverage;
import cov.CoverageAtom;
import cov.Branch;

import randoop.main.GenInputsAbstract;
import randoop.util.Log;
import randoop.util.Randomness;
import randoop.util.Reflection;
import randoop.util.SimpleList;
import randoop.util.Timer;
import randoop.util.Util;
import randoop.util.Reflection.Match;
import utilMDE.Option;
import utilMDE.Pair;

/**
 * Randoop's forward, component-based generator.
 */
public class ForwardGenerator {

	@Option("Print detailed statistics after generation.")
	public static boolean print_stats = false;
	
	@Option("When branch coverage fails to increase for the given number of seconds, stop generation.")
	public static int stop_when_plateau = -1;

    private static final int NEW_ROUND_THRESHOLD = 100;
    private static final int ROUNDS = -1;

    public final Set<Sequence> allSequences;
    private final SequenceCollection components;
    
    private final List<ExecutableSequence> regressionSequences;
    private final Timer timer = new Timer();
    private final long timeMillis;
    private final int maxSequences;

    // For testing purposes only. If Globals.randooptestrun==false then the array
    // is never populated or queried. This set contains the same set of
    // components as the set "allsequences" above, but stores them as
    // strings obtained via the toCodeString() method.
    private final List<String> allsequencesAsCode = new ArrayList<String>();

    // For testing purposes only [[comment]]
    private final List<Sequence> allsequencesAsList = new ArrayList<Sequence>();
    
    
    public final Map<CoverageAtom,Set<Sequence>> branchesToCoveringSeqs =
    	new LinkedHashMap<CoverageAtom, Set<Sequence>>();
    
    private static Set<Class<?>> instrumentedClassesCached = null;
	public Set<Class<?>> getInstrumentedClasses() {
		if (instrumentedClassesCached == null) {
			instrumentedClassesCached = new LinkedHashSet<Class<?>>();
			for (Class<?> c : covClasses) {
				if (Coverage.isInstrumented(c))
					instrumentedClassesCached.add(c);
			}
		}
		return instrumentedClassesCached;
	}
	

    public final Set<CoverageAtom> branchesCovered = new LinkedHashSet<CoverageAtom>();

    protected ObjectCache objectCache = new ObjectCache(new EqualsMethodMatcher());

    public void setObjectCache(ObjectCache newCache) {
        if (newCache == null) throw new IllegalArgumentException();
        this.objectCache = newCache;
    }

    private final ExecutionVisitor executionVisitor;
    
    public List<StatementKind> statements;
    
    public SequenceGeneratorStats stats;

    public List<Class<?>> covClasses;
	
    // Sequence construction statistics
    // ================================

    public ForwardGenerator(List<StatementKind> statements,
    		List<Class<?>> coverageClasses,
    		long timeMillis, int maxSequences,
            SequenceCollection startingcomponents) {

        this.timeMillis = timeMillis;
        this.maxSequences = maxSequences;
        this.regressionSequences = new ArrayList<ExecutableSequence>();
        this.statements = statements;
        if (coverageClasses == null)
        	this.covClasses = new ArrayList<Class<?>>();
        else
        	this.covClasses = new ArrayList<Class<?>>(coverageClasses);
        if (startingcomponents == null)
        	this.components = new SequenceCollection(SeedSequences.defaultSeeds());
        else
        	this.components = startingcomponents;
        this.executionVisitor = new DummyVisitor();
        this.allSequences = new LinkedHashSet<Sequence>();
        this.stats =  new SequenceGeneratorStats(statements, covClasses);
    }

    public Set<Sequence> allSequences() {
        return Collections.unmodifiableSet(this.allSequences);
    }

    public void processSequence(ExecutableSequence seq) {
        regressionSequences.add(seq);
        if (seq.isNormalExecution()) {
            objectCache.setActiveFlags(seq);
        } else {
            seq.sequence.clearAllActiveFlags();
        }
        
// CONTRACT-CHECKING STUFF.
//        ExecutionSummary summary =((ContractCheckingSequenceGeneratorStats) stats).updateSequenceLevelContractStatistics(seq);
//
//        if (summary == ExecutionSummary.BUG) {
//            faultsFound.add(seq);
//            seq.sequence.clearAllActiveFlags();
//            return;
//        }
//
//        if (summary == ExecutionSummary.NOT_NORMAL_NO_BUG) {
//            seq.sequence.clearAllActiveFlags();
//            return;
//        }
//
//        assert summary == ExecutionSummary.NORMAL);
//
//        if (!GenInputsAbstract.noredundancychecks) {
//            normalFound.add(seq);
//            objectCache.setActiveFlags(seq);
//        }
    }
    
    public List<ExecutableSequence> getSelectedSequences() {
        return this.regressionSequences;
    }

    protected boolean stop() {
      return
        (stop_when_plateau > 0 && stats.getGlobalStats().getCount(SequenceGeneratorStats.STAT_BRANCHTOT) == 0)
        || (stop_when_plateau > 0 && stats.progressDisplay.lastCovIncrease > stop_when_plateau)
        || (timer.getTimeElapsedMillis() >= timeMillis)
        || (allSequences.size() >= maxSequences);
    }

    protected void onStartOfExploration() {
        timer.startTiming();
    }
    /**
     * Creates and executes new sequences in a loop, using the sequences in s. New sequences
     * are themselves added to s. Stops when timer says it's testtime to stop.
     */
    public void explore() {

        Log.log(this.statements);

        stats.printLegend();

        onStartOfExploration();
 
        stats.startProgressDisplay();

        int repeatedFailedAttemptsToGenerateNewComponent = 0;
        int numRounds = 0;
        Set<Sequence> newComponents = new LinkedHashSet<Sequence>();

        while (!stop()) {
        	
            if (numRounds > ROUNDS || repeatedFailedAttemptsToGenerateNewComponent > NEW_ROUND_THRESHOLD) {
                if (numRounds < ROUNDS) System.out.println("@@@@@ NEW ROUND");
                for (Sequence s : newComponents) {
                    components.add(s);
                }
                newComponents = new LinkedHashSet<Sequence>();
                repeatedFailedAttemptsToGenerateNewComponent = 0;
                numRounds++;
            }
            
    		

            if (components.size() % GenInputsAbstract.clear == 0)
                components.clear();


    		
            Sequence newsequence = createNewUniqueSequence();
            if (newsequence == null) {
                repeatedFailedAttemptsToGenerateNewComponent++;
                continue;
            }


            if (GenInputsAbstract.dontexecute) {
                this.components.add(newsequence);
                continue;
            }

            ExecutableSequence eSeq = new ExecutableSequence(newsequence);
            

    		
            // XXX Are these all the classes we need?
            // TODO figure out serialization story for coverage data.
            Set<Branch> coveredBranches = new LinkedHashSet<Branch>();
            Set<Class<?>> classes = getInstrumentedClasses();
            Coverage.clearCoverage(classes);

            eSeq.execute(executionVisitor);
            
            for (CoverageAtom ca : Coverage.getCoveredAtoms(classes)) {
              assert ca instanceof Branch;
              coveredBranches.add((Branch)ca);
            }
            
            // Update branch-to-seqs map.
            for (CoverageAtom br : coveredBranches) {
            	branchesCovered.add(br);
            	Set<Sequence> ss = branchesToCoveringSeqs.get(br);
            	if (ss == null) {
            		ss = new LinkedHashSet<Sequence>();
            		branchesToCoveringSeqs.put(br, ss);
            	}
            	ss.add(newsequence);
            }
            
            //XXX comment out because this calls toString on user tested code and hangs on HTMLParser
            if (Log.isLoggingOn()) Log.logLine("Sequence after execution: " + Util.newLine + eSeq.toString());
            if (Log.isLoggingOn()) Log.logLine("Branches covered:" + Util.newLine + coveredBranches);

            stats.updateStatistics(eSeq, coveredBranches);

            processSequence(eSeq);

            if (GenInputsAbstract.offline) {
                newsequence.setAllActiveFlags();
                continue;
            }

            if (newsequence.hasActiveFlags()) {
                newComponents.add(newsequence);
                repeatedFailedAttemptsToGenerateNewComponent = 0;
            } else {
                repeatedFailedAttemptsToGenerateNewComponent++;
            }

            if (Log.isLoggingOn())
            	Log.logLine("allSequences.size()=" + allSequences.size());
            
        } // End of generation loop.

        stats.stopProgressDisplay();
        
        if (print_stats)
        	stats.printStatistics();
    }


    /**
     * Tries to create and execute a new sequence. If the sequence is new (not
     * already in the specivied sequence manager), then it is executed and
     * added to the manager's sequences. If the sequence created is already in
     * the manager's sequences, this method has no effect.
     */
    private Sequence createNewUniqueSequence() {

        if (Log.isLoggingOn()) Log.logLine("-------------------------------------------");

        StatementKind statement = null;
        Sequence newSequence = null;

        // Select a StatementInfo
        statement = Randomness.randomMember(this.statements);
        if (Log.isLoggingOn()) Log.logLine("Selected statement: " + statement.toString());

        stats.statStatementSelected(statement);

        InputsAndSuccessFlag  sequences = selectInputs(statement, components);

        if (!sequences.success) {
            if (Log.isLoggingOn()) Log.logLine("Failed to find inputs for statement.");
            stats.statStatementNoArgs(statement);
            return null;
        }

        newSequence = Sequence.create(statement, sequences.sequences);

        // With .5 probability, do a primitive value heuristic.
        if (GenInputsAbstract.repeat_heuristic && Randomness.nextRandomInt(10) == 0) {
	    int times = Randomness.nextRandomInt(100);
	    newSequence = newSequence.repeatLast(times);
            if (Log.isLoggingOn()) Log.log(">>>" + times + newSequence.toCodeString());
        }

        // Heuristic: if parameterless statement, subsequence inputs
        // will all be redundant, so just remove it from list of
        // statements.
        if (GenInputsAbstract.no_args_statement_heuristic && statement.getInputTypes().size() == 0) {
            statements.remove(statement);
        }

        // If sequence is larger than size limit, try again.
        if (newSequence.size() > GenInputsAbstract.maxsize) {
            if (Log.isLoggingOn()) Log.logLine("Sequence discarded because size " + newSequence.size() + " exceeds maximum allowed size " + GenInputsAbstract.maxsize);
            stats.statStatementToBig(statement);
            return null;
        }

        randoopConsistencyTests(newSequence);

        if (this.allSequences.contains(newSequence)) {
            if (Log.isLoggingOn()) Log.logLine("Sequence discarded because the same sequence was previously created.");
            stats.statStatementRepeated(statement);
            return null;
        }

        this.allSequences.add(newSequence);

        for (Pair<Sequence, Variable> p : sequences.sequences) {
            p.a.lastTimeUsed = java.lang.System.currentTimeMillis();
        }

        randoopConsistencyTest2(newSequence);

        if (Log.isLoggingOn()) {
            Log.logLine("Successfully created new unique sequence:" + newSequence.toCodeString());
        }
        //System.out.println("###" + statement.toStringVerbose() + "###" + statement.getClass());
        stats.statStatementNotDiscarded(statement);

        stats.checkStatsConsistent();

        return newSequence;
    }





    private void randoopConsistencyTest2(Sequence newSequence) {
        // Testing code.
        if (Globals.randooptestrun) {
            this.allsequencesAsCode.add(newSequence.toCodeString());
            this.allsequencesAsList.add(newSequence);
        }
    }

    private void randoopConsistencyTests(Sequence newSequence) {
        // Testing code.
        if (Globals.randooptestrun) {
            String code = newSequence.toCodeString();
            if (this.allSequences.contains(newSequence)) {
                if (!this.allsequencesAsCode.contains(code)) {
                    throw new IllegalStateException(code);
                }
            } else {
                if (this.allsequencesAsCode.contains(code)) {
                    int index = this.allsequencesAsCode.indexOf(code);
                    StringBuilder b = new StringBuilder();
                    Sequence  co = this.allsequencesAsList.get(index);
                    co.equals(newSequence);
                    b.append("new component:" + Globals.lineSep + "" + newSequence.toString()  + "" + Globals.lineSep + "as code:" + Globals.lineSep + "" + code + Globals.lineSep);
                    b.append("existing component:" + Globals.lineSep + "" + this.allsequencesAsList.get(index).toString() + "" + Globals.lineSep + "as code:" + Globals.lineSep + ""
                            + this.allsequencesAsList.get(index).toCodeString());
                    throw new IllegalStateException(b.toString());
                }
            }
        }
    }
    
    public InputsAndSuccessFlag  selectInputs(StatementKind statement, SequenceCollection  components) {

        List<Class<?>> inputClasses = statement.getInputTypes();

        List<Pair<Sequence, Variable>> ret = new ArrayList<Pair<Sequence, Variable>>();

        for (int i = 0; i < inputClasses.size(); i++) {
            Class<?> t = inputClasses.get(i);
            if(!Reflection.isVisible(t)) return new InputsAndSuccessFlag (false, ret);

           boolean isReceiver = (i == 0 && (statement instanceof RMethod) && (!((RMethod)statement).isStatic()));

            SimpleList<Sequence> l = components.getSequencesForType(t, false);

            if (l.size() == 0) {
                if (!isReceiver && GenInputsAbstract.forbid_null) {
                  return new InputsAndSuccessFlag (false, null);
                } else {
                    StatementKind st = PrimitiveOrStringOrNullDecl.nullOrZeroDecl(t);
                    Sequence seq = new Sequence().extend(st, new ArrayList<Variable>());
                    ret.add(new Pair<Sequence, Variable>(seq, seq.getLastVariable()));
                    continue;
                }
            }
            
            double nullRatio = GenInputsAbstract.null_ratio;
            assert nullRatio >=0 && nullRatio <= 1;
            boolean useNull = Randomness.randomBoolFromDistribution(1-nullRatio, nullRatio);
            if (useNull) {
              StatementKind st = PrimitiveOrStringOrNullDecl.nullOrZeroDecl(t);
              Sequence seq = new Sequence().extend(st, new ArrayList<Variable>());
              ret.add(new Pair<Sequence, Variable>(seq, seq.getLastVariable()));
              continue;
            }
            
            Sequence chosenSeq = null;
            if (GenInputsAbstract.weighted_inputs) {
                chosenSeq = Randomness.randomMemberWeighted(l);
            } else {
                chosenSeq = Randomness.randomMember(l);
            }

            // Now, find values that satisfy the constraint set.
            Match m = Match.COMPATIBLE_TYPE;
            //if (i == 0 && statement.isInstanceMethod()) m = Match.EXACT_TYPE;
            Variable randomVariable = chosenSeq.randomVariableForTypeLastStatement(t, m);

            if (randomVariable == null) {
                throw new BugInRandoopException("type: " + t + ", sequence: " + chosenSeq);
            }

            if (i == 0
            		&& (statement instanceof RMethod)
            		&& (!((RMethod) statement).isStatic())
					&& chosenSeq.getCreatingStatement(randomVariable) instanceof PrimitiveOrStringOrNullDecl)
                return new InputsAndSuccessFlag (false, null);
            ret.add(new Pair<Sequence ,Variable >(chosenSeq, randomVariable));
        }

        return new InputsAndSuccessFlag (true, ret);
    }

}
