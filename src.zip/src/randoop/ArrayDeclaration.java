package randoop;

import java.io.ObjectStreamException;
import java.io.PrintStream;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import randoop.util.SerializationHelper;
import randoop.util.Util;

/**
 * Immutable.
 * Represents an array creation statement, e.g. "int[] x = new int[2] { 3, 7 };"
  */
public final class ArrayDeclaration implements StatementKind, Serializable {
	
  /** ID for parsing purposes (see StatementKinds.parse method) */
  public static final String ID = "array";

    // The maximum number of elements allowed in the array creation.
    private final static int MAX_ARRAY_SIZE = 10;
    
    // State variables.
    private final int length;
    private final Class<?> elementType;
    
    // Cached values (for improved performance). Their values
    // are computed upon the first invocation of the respective
    // getter method.
    private List<Class<?>> inputTypesCached;
    private Class<?> outputTypeCached;    
    private int hashCodeCached;
    private boolean hashCodeComputed= false;
    
    /**
     * @param elementType type of objects in the array
     * @param length number of objects allowed in the array
     */
    public ArrayDeclaration(Class<?> elementType, int length) {
    	
    	// Check legality of arguments.
        if (elementType == null) throw new IllegalArgumentException("elementType cannot be null.");
        if (length < 0) throw new IllegalArgumentException("arity cannot be less than zero: " + length);
        if (length > MAX_ARRAY_SIZE)
            throw new IllegalArgumentException("ArrayDeclarationInfo.MAX_ARRAY_SIZE"
                    + ArrayDeclaration.MAX_ARRAY_SIZE
                    + " exceeded by arity=" + length);
        
        // Set state variables.
        this.elementType = elementType;
        this.length = length;
    }
    
    private Object writeReplace() throws ObjectStreamException {
      return new SerializableArrayDeclaration(elementType, length);
    }

    /**
     * Returns the class of type of elements held in this ArrayDeclarationInfo
     */
    public Class<?> getElementType() {
        return this.elementType;
    }
    
    /**
     * Extracts the input constraints for this ArrayDeclarationInfo
     * @return list of input constraints
     */
    public List<Class<?>> getInputTypes() {
    	if (inputTypesCached == null) {
			this.inputTypesCached = new ArrayList<Class<?>>(length);
			for (int i = 0 ; i < length ; i++)
				inputTypesCached.add(elementType);
			inputTypesCached = Collections.unmodifiableList(inputTypesCached);
		}
        return Collections.unmodifiableList(this.inputTypesCached);
    }
    
    /**
     * Executes this statement, given the inputs to the statement. Returns
     * the results of execution as an ResultOrException object and can 
     * output results to specified PrintStream.
     */
	public ExecutionOutcome execute(Object[] statementInput, PrintStream out) {
		if (statementInput.length > length)
			throw new IllegalArgumentException("Too many arguments:"
					+ statementInput.length + " capacity:" + length);
		long startTime = System.currentTimeMillis();
		assert statementInput.length == this.length;
		Object theArray = Array.newInstance(this.elementType, this.length);
		for (int i = 0; i < statementInput.length; i++)
			Array.set(theArray, i, statementInput[i]);
		long totalTime = System.currentTimeMillis() - startTime;
		return new NormalExecution(theArray, totalTime);
	}

    @Override
    public String toString() {
        return "array_of_" + this.elementType.getSimpleName() + "_of_size_" + this.length;
    }

    public String toStringShort() {
        return toString();
    }
    
    public String toStringVerbose() {
        return toString();
    }
    
    /**
     * Returns constraint to represent new reference to this statement,
     * namely the receiver that is generated.
     */
    public Class<?> getOutputType() {
    	if (outputTypeCached == null) {
			outputTypeCached = Array.newInstance(elementType, 0).getClass();
    	}
        return outputTypeCached;
    }
    
    /**
     * Appends string representation of ArrayDeclarationInfo into b.
     */
    public void appendCode(String varNum, String[] inputString, StringBuilder b) {
        if (inputString.length > length)
        	throw new IllegalArgumentException("Too many arguments:"
        			+ inputString.length + " capacity:" + length);
        String declaringClass = this.elementType.getCanonicalName();
        b.append(declaringClass + "[] " + varNum + " = new " + declaringClass + "[] { ");
        for (int i = 0 ; i < inputString.length ; i++) {
            if (i > 0)
                b.append(", ");
            b.append(inputString[i]);
        }
        b.append("};");
        b.append(Util.newLine);
    }

    @Override
    public int hashCode() {
        if (!hashCodeComputed) {
            hashCodeComputed = true;
            hashCodeCached = this.elementType.hashCode();
            hashCodeCached += this.length * 17;
        }
        return new Integer(hashCodeCached);
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof ArrayDeclaration))
            return false;
        if (this == o)
            return true;
        ArrayDeclaration otherArrayDecl = (ArrayDeclaration) o;
        if (!this.elementType.equals(otherArrayDecl.elementType))
            return false;
        if (this.length != otherArrayDecl.length)
            return false;
        return true;
    }

    public String toParseableString() {
      return SerializationHelper.serializeClass(elementType) + "[" + Integer.toString(length) + "]";
    }

    public static StatementKind parse(String str) {
      int openBr = str.indexOf('[');
      int closeBr = str.indexOf(']');
      String elementTypeStr = str.substring(0, openBr);
      String lengthStr = str.substring(openBr + 1, closeBr);
      Class<?> elementType = SerializationHelper.deserializeClass(elementTypeStr);
      int length = Integer.parseInt(lengthStr);
      return new ArrayDeclaration(elementType, length);
    }
}