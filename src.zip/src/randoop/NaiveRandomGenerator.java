
package randoop;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import randoop.util.CollectionsExt;
import randoop.util.Randomness;
import randoop.util.Reflection;
import randoop.util.TypeToObjectMap;
import randoop.util.Util;
import utilMDE.Pair;

public class NaiveRandomGenerator {

	SubTypeSet availableTypes = new SubTypeSet();

	Map<Class<?>, Set<Variable>> typesToVals = new LinkedHashMap<Class<?>, Set<Variable>>();

	List<StatementKind> activeStatements = new ArrayList<StatementKind>();

	Map<Class<?>, Set<StatementKind>> missingTypesToStatements = new LinkedHashMap<Class<?>, Set<StatementKind>>();

	Map<StatementKind, Set<Class<?>>> inactiveStatements = new LinkedHashMap<StatementKind, Set<Class<?>>>();

	Sequence sequence;

	List<StatementKind> allStatements;

	List<ExecutionOutcome> executionResults;

	void repInvariantCheck() {
		try {
			repInvariantCheck2();
		} catch (Exception e) {
			try {
				writeLog(e, true);
			} catch (IOException e1) {
				System.out
				.println("Error while writing log:" + e1.getMessage());
			}
			throw new RuntimeException(e);
		}
	}

	@SuppressWarnings( { "unchecked" })
	void repInvariantCheck2() {

		Set<StatementKind> activeStatementsAsSet = new LinkedHashSet<StatementKind>(
				activeStatements);

		// activeStatements is a subset of allStatements.
		assert allStatements
				.containsAll(activeStatementsAsSet);

		// activeStatements and inactiveStatements partition allStatements.
		assert CollectionsExt.intersection(activeStatementsAsSet,
				inactiveStatements.keySet()).isEmpty();
		Set<StatementKind> union = new LinkedHashSet<StatementKind>(activeStatements);
		union.addAll(inactiveStatements.keySet());
		assert union.equals(new LinkedHashSet<StatementKind>(allStatements));

		// missingTypes and activeTypes are disjoint.
		assert CollectionsExt
				.intersection(availableTypes.getElements(),
						missingTypesToStatements.keySet()).isEmpty();

		// missingTypesToStatements and inactiveStatements: the collections of
		// missing classes is the same.
		Set<Class<?>> classSet1 = missingTypesToStatements.keySet();
		Set<Class<?>> classSet2 = new LinkedHashSet<Class<?>>();
		for (Set<Class<?>> cs : inactiveStatements.values()) {
			classSet2.addAll(cs);
		}
		assert classSet1.equals(classSet2) : classSet1 + "," + classSet2;

		// missingTypesToStatements and inactiveStatements: the collections of
		// inactive statements is the same.
		Set<StatementKind> stSet1 = inactiveStatements.keySet();
		Set<StatementKind> stSet2 = new LinkedHashSet<StatementKind>();
		for (Set<StatementKind> ss : missingTypesToStatements.values()) {
			stSet2.addAll(ss);
		}
		assert stSet1.equals(stSet2);

		// A type in in availableTypes iff it is in typesToVals.
		typesToVals.keySet().equals(availableTypes.getElements());

		// (Without feedback only) Every value in the sequence is in exactly one
		// entry.
		Set<Variable> valuesSoFar = new LinkedHashSet<Variable>();
		for (Set<Variable> s : typesToVals.values()) {
			for (Variable v : s) {
				assert !valuesSoFar.contains(v);
				valuesSoFar.add(v);
			}
		}
		assert valuesSoFar.equals(new LinkedHashSet<Variable>(sequence
				.getAllVariables()));

		for (Class<?> c : typesToVals.keySet()) {
			assert c != null;
		}

		for (Class<?> c : missingTypesToStatements.keySet()) {
			assert c != null;
		}

		assert !activeStatements.contains(null);

		for (StatementKind st : inactiveStatements.keySet()) {
			assert st != null;
		}

		// TODO move this to repCheck for List<StatementKind>.
		for (StatementKind st : allStatements) {
			assert st != null;
		}

		// inactiveStatements never maps to an empty set.
		for (Set<Class<?>> s : inactiveStatements.values()) {
			assert s != null;
			assert !s.isEmpty();
		}

		// missingTypesToStatements never maps to an empty set.
		for (Set<StatementKind> s : missingTypesToStatements.values()) {
			assert s != null;
			assert !s.isEmpty();
		}

		// typesToVals map never maps to an empty set.
		for (Set<Variable> s : typesToVals.values()) {
			assert s != null;
			assert !s.isEmpty();
		}

		for (StatementKind st : allStatements) {

			boolean isInActiveStatements = activeStatements.contains(st);

			boolean isInInactiveStatements = inactiveStatements.keySet()
			.contains(st);

			boolean hasAllArgTypesInAvailableTypes = true;
			for (Class<?> c : getInputTypesSet(st)) {
				if (!availableTypes.containsAssignableType(c,
						Reflection.Match.COMPATIBLE_TYPE)) {
					hasAllArgTypesInAvailableTypes = false;
					break;
				}
			}

			boolean hasSomeArgTypesInMissingTypes = !CollectionsExt
			.intersection(missingTypesToStatements.keySet(),
					getInputTypesSet(st)).isEmpty();

			// A statement is in the active set iff it has all its argument
			// types in the availableTypes set.
			assert Util.iff(isInActiveStatements,
					hasAllArgTypesInAvailableTypes) : st.toString();
			assert Util.iff(isInActiveStatements,
					!hasSomeArgTypesInMissingTypes);

			assert Util.iff(isInInactiveStatements,
					!hasAllArgTypesInAvailableTypes);
			assert Util.iff(isInInactiveStatements,
					hasSomeArgTypesInMissingTypes);

			Set<Class<?>> missingTypesForSt1 = inactiveStatements.get(st);
			if (missingTypesForSt1 == null)
				missingTypesForSt1 = new LinkedHashSet<Class<?>>();

			Set<Class<?>> missingTypesForSt2 = new LinkedHashSet<Class<?>>();
			for (Map.Entry<Class<?>, Set<StatementKind>> e : missingTypesToStatements
					.entrySet()) {
				if (e.getValue().contains(st)) {
					missingTypesForSt2.add(e.getKey());
				}
			}

			assert missingTypesForSt1.equals(missingTypesForSt2);

			assert Util.iff(missingTypesForSt2.isEmpty(),
					activeStatementsAsSet.contains(st));
		}

	}

	private Set<Class<?>> getInputTypesSet(StatementKind st) {
		throw new RuntimeException("not implemented.");
	}

	public static void generateSequences(List<StatementKind> statements,
			int numSequences, int sequenceLength) throws IOException {
		NaiveRandomGeneratorFactory factory = new NaiveRandomGeneratorFactory(
				statements);
		for (int i = 0; i < numSequences; i++) {
			System.out.print(".");
			if (i % 80 == 0)
				System.out.println();
			NaiveRandomGenerator generator = null;
			generator = factory.create();
			// generator.writeLog(null, false);
			for (int elt = 0; elt < sequenceLength; elt++) {
				// generator.writeLog(null, true);
				boolean extendAgain = generator.extendRandomly();
				if (!extendAgain)
					break;
			}
		}
	}

	private void writeLog(Exception ex, boolean append) throws IOException {

		File f = new File("/tmp/carloslog.txt");
		BufferedWriter writer = new BufferedWriter(new FileWriter(f, append));

		writer
		.write("***********************************************************");

		writer.write("===SEQUENCE" + Util.newLine);
		writer.write(sequence.toString());
		writer.write(Util.newLine);

		if (ex != null) {
			writer.write("===EXCEPTION THROWN" + Util.newLine);
			writer.write("===MESSAGE" + Util.newLine + ex.getMessage()
					+ Util.newLine);
			writer.write("STACK TRACE" + Util.newLine);
			ex.printStackTrace(new PrintWriter(writer)); // TODO close?
		}

		writer.write("===AVAILABLETYPES" + Util.newLine);
		for (Class<?> c : availableTypes.getElements()) {
			writer.write(c + Util.newLine);
		}
		writer.write(Util.newLine);

		writer.write("===MISSINGTYPES" + Util.newLine);
		for (Map.Entry<Class<?>, Set<StatementKind>> e : missingTypesToStatements
				.entrySet()) {
			writer.write(e.getKey() + Util.newLine);
			for (StatementKind s : e.getValue())
				writer.write("   " + s.toString() + Util.newLine);
		}
		writer.write(Util.newLine);

		writer.write("===ACTIVESTATEMENTS" + Util.newLine);
		for (StatementKind st : activeStatements) {
			writer.write(st.toString() + Util.newLine);
		}
		writer.write(Util.newLine);

		writer.write("===INACTIVESTATEMENTS" + Util.newLine);
		for (Map.Entry<StatementKind, Set<Class<?>>> e : inactiveStatements
				.entrySet()) {
			writer.write(e.getKey().toString() + Util.newLine);
			for (Class<?> c : e.getValue()) {
				writer.write("   " + c + Util.newLine);
			}
		}
		writer.write(Util.newLine);

		writer.write("===TYPESTOVALS" + Util.newLine);
		for (Map.Entry<Class<?>, Set<Variable>> e : typesToVals.entrySet()) {
			writer.write(e.getKey() + Util.newLine);
			for (Variable v : e.getValue()) {
				writer.write("   " + v + Util.newLine);
			}
		}
		writer.write(Util.newLine);

		writer.flush();
		writer.close();
	}

	TypeToObjectMap objectMap = new TypeToObjectMap();

//	private static ContractCheckingVisitor faultFinder = new ContractCheckingVisitor(ContractCheckingVisitor.defaultCheckers());

	static {
//		List<Observation> checkers = new ArrayList<Observation>();
		//checkers.add(new EqualsNotReflexive());
		//checkers.add(new EqualsToNull());
//		checkers.add(new CompareToNotReverseSign());
		//checkers.add(new EqualsHashcodeContractViolated());
//		checkers.add(new EqualsNotSymmetric());
//		checkers.add(new CompareToNotTransitive());
//		checkers.add(new CompareToTernaryContractViolated());
//		checkers.add(new EqualsNotTransitive());
//		faultFinder = new ContractCheckingVisitor(checkers);
	}

	public static Map<StatementKind, Integer> smap = new LinkedHashMap<StatementKind, Integer>();

	private void updateSmap(StatementKind st) {

		Integer i = smap.get(st);
		if (i == null) {
			i = 0;
		}
		smap.put(st, i+1);
	}


	private boolean extendRandomly() {

		StatementKind st = Randomness.randomSetMember(activeStatements);

		updateSmap(st);

		List<Variable> vals = getRandomVariables(sequence, st);

		// update sequence
		sequence = sequence.extend(st, vals);
		
		if (true) return true;
		
		// Execute statement.
		int lastIdx = sequence.size() - 1;
		List<Variable> inputs = sequence.getInputs(lastIdx);
		Object[] inputVariables = new Object[inputs.size()];

		for (int j = 0; j < inputVariables.length; j++) {
			int creatingStatementIdx = inputs.get(j).getIndex();
			assert (executionResults.get(creatingStatementIdx) instanceof NormalExecution);
			NormalExecution ne = (NormalExecution) executionResults
			.get(creatingStatementIdx);
			inputVariables[j] = ne.getRuntimeVariable();
			assert inputVariables[j] != null;
		}

		ExecutionOutcome outcome = st.execute(inputVariables,
				Globals.blackHole);
		executionResults.add(outcome);
		
		if (outcome instanceof ExceptionalExecution)
			return true;

		assert outcome instanceof NormalExecution;

		// HOT OBJECT!!
		Object o = ((NormalExecution) outcome).getRuntimeVariable();

		if (o == null)
			return true;

		objectMap.addObject(o);

		for (Map.Entry<Class<?>, List<TypeToObjectMap.HotPotato>> e : objectMap.theMap
				.entrySet()) {
			List<TypeToObjectMap.HotPotato> list = e.getValue();
			Object[] oa = new Object[list.size()];
			for (int i = 0; i < list.size(); i++) {
				oa[i] = list.get(i).o;
			}

			List<Pair<Observation, Object[]>> faults = null; // XXX
			if (faults.size() > 0) {
				for (Pair<Observation, Object[]> p : faults) {
					System.out.println(p.a.getClass().getName() + "("
							+ p.b[0].getClass().getName() + ")");
					System.out.println("***");
					System.out.println(sequence.toCodeString());
					System.out.println("***");
				}
				return false;
			}
		}

		Class<?> retType = st.getOutputType();

		// update availableTypes
		availableTypes.add(retType);

		// update typesToVals
		Set<Variable> seqVals = typesToVals.get(retType);
		if (seqVals == null) {
			seqVals = new LinkedHashSet<Variable>();
			typesToVals.put(retType, seqVals);
		}
		seqVals.add(sequence.getLastVariable());

		// update missingTypesToStatements, activeStatements and
		// inactiveStatements.
		for (Iterator<Map.Entry<Class<?>, Set<StatementKind>>> i = missingTypesToStatements
				.entrySet().iterator(); i.hasNext();) {
			Map.Entry<Class<?>, Set<StatementKind>> e = i.next();
			if (e.getKey().isAssignableFrom(retType)) {
				for (StatementKind st2 : e.getValue()) {
					Set<Class<?>> missingTypes = inactiveStatements.get(st2);
					missingTypes.remove(e.getKey());
					if (missingTypes.isEmpty()) {
						inactiveStatements.remove(st2);
						activeStatements.add(st2);
					}
				}
				i.remove();
			}
		}

		return true;

		// repInvariantCheck();
	}

	private List<Variable> getRandomVariables(Sequence s, StatementKind st) {
		if (st == null)
			throw new IllegalArgumentException("argument cannot be null.");
		// if (!activeStatements.contains(st))
		// throw new IllegalArgumentException();

		List<Variable> vals = new ArrayList<Variable>();
		for (Class<?> tc : st.getInputTypes()) {

			// Randomly select a type.
			Class<?> inputType = Randomness.randomMember(availableTypes
					.getMatches(tc));
			List<Variable> candidateVariables = new ArrayList<Variable>(typesToVals
					.get(inputType));
			// Randomly select a value.
			Variable chosenVal = Randomness.randomMember(candidateVariables);
			vals.add(s.getVariable(chosenVal.getIndex()));
		}
		return vals;
	}
}
