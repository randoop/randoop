/**
 * 
 */
package randoop;

import java.util.ArrayList;
import java.util.List;

/**
 * A statement call that is part of a mutable sequence.
 */
public class MStatementCall {

	public final StatementKind statement;

	public final List<MVariable> inputs;

	public final MVariable result;

	/**
	 * Create a new statement of type statement that takes as input the
	 * given values.
	 */
	public MStatementCall(StatementKind statement, List<MVariable> inputVariables, MVariable result) {
		this.statement = statement;
		this.inputs = new ArrayList<MVariable>(inputVariables);
		this.result = result;
	}
}