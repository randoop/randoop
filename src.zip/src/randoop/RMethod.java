package randoop;

import java.io.ObjectStreamException;
import java.io.PrintStream;
import java.io.Serializable;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import randoop.util.CodeWriting;
import randoop.util.CollectionsExt;
import randoop.util.MethodReflectionCode;
import randoop.util.PrimitiveTypes;
import randoop.util.ReflectionExecutor;
import randoop.util.SerializationHelper;
import randoop.util.Util;
import utilMDE.UtilMDE;

/**
 * Represents a method call.
 * 
 * The "R" stands for "Randoop", to underline the distinction from
 * java.lang.reflect.Method.
 */
public final class RMethod implements StatementKind, Serializable {

	private static final long serialVersionUID = -7616184807726929835L;
	
  /** ID for parsing purposes (see StatementKinds.parse method) */
  public static final String ID = "method";

	// State variable.
	private final Method method;

	// Cached values (for improved performance). Their values
	// are computed upon the first invocation of the respective
	// getter method.
	private List<Class<?>> inputTypesCached;
	private Class<?> outputTypeCached;
	private boolean hashCodeComputed = false;
	private int hashCodeCached = 0;
	private boolean isVoidComputed = false;
	private boolean isVoidCached = false;
	private boolean isStaticComputed = false;
	private boolean isStaticCached = false;

	private Object writeReplace() throws ObjectStreamException {
		return new SerializableRMethod(method);
	}


	/**
	 * Returns Method object represented by this MethodCallInfo
	 */
	public Method getMethod() {
		return this.method;
	}

	/*
	 * Creates MethodCallInfo from specified method by generating its input and
	 * output constraints.
	 */
	private RMethod(Method method) {
		if (method == null)
			throw new IllegalArgumentException("method should not be null.");

		this.method = method;
		// TODO move this earlier in the process: check first that all
		// methods to be used can be made accessible.
		// XXX this should not be here but I get infinite loop when comment out
		this.method.setAccessible(true);
	}

	/**
	 * Returns the statement corresponding to the given constructor.
	 */
	public static RMethod getRMethod(Method method) {
		return new RMethod(method);
	}

	@Override
	public String toString() {
	  return toParseableString();
	}

	// TODO: integrate with below method
	public void appendCode(String varNum, String[] inputString, StringBuilder b) {
		appendAsCode(varNum, inputString, b, false);
	}

	/*
	 * Helper function that appends string representation of this MethodCallInfo
	 * to b
	 */
	private void appendAsCode(String varName, String[] inputString,
			StringBuilder b, boolean addCheckSpec) {

		// HACK HACK HACK! We're going to hardcode a checkSpec for each
		// object after every method call. The checkSpec method checks
		// the set of unary contracts that we currently have).
		if (addCheckSpec) {
			if (!isStatic())
				b.append("checkSpec(" + inputString[0] + ");"
								+ Globals.lineSep);
			for (int i = 1; i < inputString.length; i++) {
				if (inputString[i].startsWith("p")) {
					b.append("checkSpec(" + inputString[i] + ");"
							+ Globals.lineSep);
				}
			}
		}

		appendReturnVarDecl(varName, b);
		appendMethodCall(inputString, b);
	}

	private void appendMethodCall(String[] inputStrings, StringBuilder b) {

		String receiverString = isStatic() ? null : inputStrings[0];
		appendReceiverOrClassForStatics(receiverString, b);

		String[] paramStrings = null;
		if (isStatic()) {
			paramStrings = inputStrings;
		} else {
			paramStrings = new String[inputStrings.length - 1];
			for (int i = 1; i < inputStrings.length; i++)
				paramStrings[i - 1] = inputStrings[i];
		}
		b.append(".");
		b.append(getTypeArguments());
		b.append(this.method.getName() + "(");
		appendActualParameters(paramStrings, b);
		b.append(");" + Util.newLine);
	}

	// XXX this is a pretty bogus workaround for a bug in javac (type inference
	// fails sometimes)
	// It is bogus because what we produce here may be different from correct
	// infered type.
	private String getTypeArguments() {
		TypeVariable<Method>[] typeParameters = method.getTypeParameters();
		if (typeParameters.length == 0)
			return "";
		StringBuilder b = new StringBuilder();
		Class<?>[] params = new Class[typeParameters.length];
		b.append("<");
		for (int i = 0; i < typeParameters.length; i++) {
			if (i > 0)
				b.append(",");
			Type firstBound = typeParameters[i].getBounds().length == 0 ? Object.class
					: typeParameters[i].getBounds()[0];
			params[i] = getErasure(firstBound);
			b.append(getErasure(firstBound).getCanonicalName());
		}
		b.append(">");
		// if all are object, then don't bother
		if (CollectionsExt.findAll(Arrays.asList(params), Object.class).size() == params.length)
			return "";
		return b.toString();
	}

	private static Class<?> getErasure(Type t) {
		if (t instanceof Class)
			return (Class<?>) t;
		if (t instanceof ParameterizedType) {
			ParameterizedType pt = (ParameterizedType) t;
			return getErasure(pt.getRawType());
		}
		if (t instanceof TypeVariable) {
			TypeVariable<?> tv = (TypeVariable<?>) t;
			Type[] bounds = tv.getBounds();
			Type firstBound = bounds.length == 0 ? Object.class : bounds[0];
			return getErasure(firstBound);
		}
		if (t instanceof GenericArrayType)
			throw new UnsupportedOperationException(
					"erasure of arrays not implemented " + t);
		if (t instanceof WildcardType)
			throw new UnsupportedOperationException(
					"erasure of wildcards not implemented " + t);
		throw new IllegalStateException("unexpected type " + t);
	}

	private void appendActualParameters(String[] paramStrings, StringBuilder b) {
		for (int i = 0; i < paramStrings.length; i++) {
			if (i > 0)
				b.append(", ");

			// presently we always cast, to prevent the compiler from
			// complaining. TODO cast only if necesary
			b.append("(" + method.getParameterTypes()[i].getCanonicalName() + ")");

			b.append(paramStrings[i]);
		}
	}

	private void appendReceiverOrClassForStatics(String receiverString,
			StringBuilder b) {
		if (isStatic()) {
			String s2 = this.method.getDeclaringClass().getName().replace('$',
					'.'); // TODO combine this with last if clause
			b.append(s2);
		} else {
			Class<?> expectedType = getInputTypes().get(0);
			String canonicalName = expectedType.getCanonicalName();
			boolean mustCast = canonicalName != null
					&& PrimitiveTypes
							.isBoxedPrimitiveTypeOrString(expectedType)
					&& !expectedType.equals(String.class);
			if (mustCast) {
				// this is a little paranoid but we need to cast primitives in
				// order to get them boxed.
				b.append("((" + canonicalName + ")" + receiverString + ")");
			} else {
				b.append(receiverString);
			}
		}
	}

	private void appendReturnVarDecl(String varName, StringBuilder b) {
		if (!isVoid()) {
			b.append(CodeWriting.getCompilableClassnameString(this.method
					.getReturnType().getName()));
			String cast = "";
			b.append(" " + varName + " = " + cast);
		}
	}

	@Testable
	@Override
	public boolean equals(Object o) {
		if (!(o instanceof RMethod))
			return false;
		if (this == o)
			return true;
		RMethod other = (RMethod) o;
		if (!this.method.equals(other.method))
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		if (!hashCodeComputed) {
			hashCodeComputed = true;
			hashCodeCached = this.method.hashCode();
		}
		return hashCodeCached;
	}

	public ExecutionOutcome execute(Object[] statementInput, PrintStream out) {

		assert statementInput.length == getInputTypes().size();

		Object receiver = null;
		int paramsLength = getInputTypes().size();
		int paramsStartIndex = 0;
		if (!isStatic()) {
			receiver = statementInput[0];
			paramsLength--;
			paramsStartIndex = 1;
		}

		Object[] params = new Object[paramsLength];
		for (int i = 0; i < params.length; i++) {
			params[i] = statementInput[i + paramsStartIndex];
		}

		MethodReflectionCode code = new MethodReflectionCode(this.method,
				receiver, params);

		long startTime = System.currentTimeMillis();
		Throwable thrown = ReflectionExecutor.executeReflectionCode(code, out);
		long totalTime = System.currentTimeMillis() - startTime;

		if (thrown == null) {
			return new NormalExecution(code.getReturnVariable(), totalTime);
		} else {
			return new ExceptionalExecution(thrown, totalTime);
		}
	}

	/**
	 * Extracts the input constraints for this MethodCallInfo
	 * 
	 * @return list of input constraints
	 */
	public List<Class<?>> getInputTypes() {
		if (inputTypesCached == null) {
			Class<?>[] methodParameterTypes = method.getParameterTypes();
			inputTypesCached = new ArrayList<Class<?>>(
					methodParameterTypes.length + (isStatic() ? 0 : 1));
			if (!isStatic())
				inputTypesCached.add(method.getDeclaringClass());
			for (int i = 0; i < methodParameterTypes.length; i++) {
				inputTypesCached.add(methodParameterTypes[i]);
			}
		}
		return inputTypesCached;
	}

	/**
	 * Returns constraint to represent new reference to this statement. Returns
	 * null if method represented by this MethodCallInfo is a void method,
	 * returns the return value otherwise.
	 */
	public Class<?> getOutputType() {
		if (outputTypeCached == null) {
			outputTypeCached = method.getReturnType();
		}
		return outputTypeCached;
	}

	private boolean isVoid() {
		if (!isVoidComputed) {
			isVoidComputed = true;
			isVoidCached = void.class.equals(this.method.getReturnType());
		}
		return isVoidCached;
	}

	/**
	 * Returns true if method represented by this MethodCallInfo is a static
	 * method.
	 */
	public boolean isStatic() {
		if (!isStaticComputed) {
			isStaticComputed = true;
			isStaticCached = Modifier.isStatic(this.method.getModifiers());
		}
		return this.isStaticCached;
	}

  public String toParseableString() {
    return SerializationHelper.serializeMethod(method);
  }

  public static StatementKind parse(String s) {
    return RMethod.getRMethod(SerializationHelper.deserializeMethod(s));
  }
}
