package randoop;

/**
 * The expression "x0.equals(null)"
 */
public final class EqualsToNull implements Expression {

    public EqualsToNull() {
        /*empty*/
    }
    
    public Object evaluate(Object... objects) {
		assert objects != null && objects.length == 1;
        return objects[0].equals(null);
    }
    
	public int getArity() {
		return 1;
	}
}