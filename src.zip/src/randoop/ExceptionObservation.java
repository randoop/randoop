package randoop;

import java.io.ObjectStreamException;
import java.io.Serializable;

import randoop.util.Util;

/**
 * An observation recording the exception that a particular
 * statement threw during execution.
 */
public class ExceptionObservation implements Observation, Serializable {

	private final Class<? extends Throwable> exceptionClass; 

	public ExceptionObservation(Throwable exception) {
		if (exception == null)
			throw new IllegalArgumentException("exception cannot be null.");
		this.exceptionClass = exception.getClass();
	}

	private Object writeReplace() throws ObjectStreamException {
		return new SerializableExceptionObservation(exceptionClass);
	}

	public String toString() {
		return "// throws exception of type " + exceptionClass.getName() + Util.newLine;
	}

	/**
	 * The "try" half of the try-catch wrapper.
	 */
	public String toCodeStringPreStatement() {
		StringBuilder b = new StringBuilder();
		b.append("boolean threwCorrectException = false;" + Util.newLine);
		b.append("try {" + Util.newLine + "\t");
		return b.toString();
	}

	/**
	 * The "catch" half of the try-catch wrapper.
	 */
	public String toCodeStringPostStatement() {
		StringBuilder b = new StringBuilder();
		String exceptionClassName = exceptionClass.getCanonicalName();
		b.append("} catch (Throwable e) {" + Util.newLine);
		b.append("\tthrewCorrectException = (");
		b.append(exceptionClassName);
		b.append(".class).equals(e.getClass());" + Util.newLine);
		b.append("}" + Util.newLine);
		b.append("assertTrue(\"code should throw the exception ");
		b.append(exceptionClassName);
		b.append("\", threwCorrectException);" + Util.newLine);
		return b.toString();
	}


}
