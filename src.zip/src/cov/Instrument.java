package cov;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.BodyDeclaration;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.EnumDeclaration;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ForStatement;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.PackageDeclaration;
import org.eclipse.jdt.core.dom.SingleMemberAnnotation;
import org.eclipse.jdt.core.dom.StringLiteral;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.WhileStatement;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.Document;
import org.eclipse.text.edits.TextEdit;

import randoop.util.Files;
import utilMDE.Option;
import utilMDE.Options;
import utilMDE.Pair;
import utilMDE.Options.ArgException;

/**
 * The source code coverage instrumenter.
 * 
 * Usage:
 * 
 * java simplecov.Instrument [OPTIONS] dir...
 * 
 * 
 * Notes:
 * 
 * Coverage info stored only for top-level classes.
 * 
 * Method-level info is only available for top-level methods. Top-level methods
 * are methods directly declared in a top-level class. This is for no important
 * reason. TO-DO is to add inner-class methods. Note however that
 * anonymous-class methods should probably not be instrumented because we have
 * no way of reaching them by calling the methods directly.
 * 
 * If a method is declared within another method (via a class declaration), the
 * branches of the inner will be assigned to the outermost containing method
 * declaration.
 * 
 * Do not instrument branches inside annotation declarations.
 */
@SuppressWarnings("unchecked")
public class Instrument extends ASTVisitor {

	@Option("Destination directory for instrumented files (REQUIRED OPTION).")
	public static String destination = null;

	@Option("Overwrite contents of instrumented directory, if present.")
	public static boolean overwrite = false;

	@Option("Specify instrumentation type.")
	public static boolean printout = false;
	
	@Option("File containing a list of source files to instrument")
	public static List<String> files = new ArrayList<String>();

	static AST ast;

	private static CompilationUnit unit;

	private static int branchNumber;
	private static int classDepth = 0;
	private static int methodDepth = 0;
	private static int methodId = 0;
	private static Map<String,Set<Integer>> allMethodIndices = null;
	private static Map<String,Pair<Integer,Integer>> allMethodLineSpans = null;

	private static Set<Integer> oneMethodIndices = null;
	private static List<Integer> branchToLine = null;

	public static String isInstrumentedField = "simplecov_instrumented";
	public static String MethodIdAnnotation = "SimpleCovMethodId";
	public static String trueBranches = "trueBranches";
	public static String falseBranches = "falseBranches";
	public static String branchLines = "branchLines";
	public static String methodIdToBranches = "methodIdToBranches";
	public static String sourceFileNameField = "sourceFileName";
	public static String sourceFileName = null;

	public static String methodLineSpansField = "methodLineSpans";

	public static void main(String[] args) throws ArgException, IOException {

		Options options = new Options(Instrument.class);
		options.parse(args);
		if (destination == null) {
			System.out.println("Missing required option --destination=<dir>");
			System.exit(1);
		}
		File destinationDir = new File(destination);
		if (destinationDir.exists() && !overwrite) {
			System.out.println("Destination directory \"" + destinationDir +
			"\" exists but --overwrite option was not given. Will not proceed.");
			System.exit(1);
		}

		List<String> javaFileNames = new ArrayList<String>();
		if (!files.isEmpty())
			javaFileNames.addAll(readJavaFileNames(files));
		javaFileNames.addAll(FilesUtil.getJavaFileNames(Arrays.asList(args)));

		for (String oneFileStr : javaFileNames) {
			
			File oneFile = new File(oneFileStr);
			
			sourceFileName = oneFile.getName();

			System.out.println("Instrumenting " + oneFile);

			ASTParser parser = ASTParser.newParser(AST.JLS3);
			Hashtable h = new Hashtable();
			h.put(JavaCore.COMPILER_SOURCE, "1.5");
			parser.setCompilerOptions(h);
			String fileContents = Files.getFileContents(oneFile);
			parser.setSource(fileContents.toCharArray());
			unit = (CompilationUnit) parser.createAST(null);
			unit.recordModifications();
			ast = unit.getAST();

			assert classDepth == 0;
			assert methodDepth == 0;
			assert allMethodIndices == null;
			assert allMethodLineSpans == null;
			assert oneMethodIndices == null;
			assert branchToLine == null;
			
			unit.accept(new Instrument());

			String packageName = "";
			PackageDeclaration packageDecl = unit.getPackage();
			if (packageDecl != null)
				packageName = unit.getPackage().getName().toString();

			try {

				File instrumentedFileDir = new File(destinationDir.getPath()
						+ File.separator
						+ packageName.replace(".", File.separator));

				if (!instrumentedFileDir.exists()) {
					instrumentedFileDir.mkdirs();
				}

				// Output instrumented class
				String instrumentedFileName = oneFile.getName();
				File instrumentedFile = new File(instrumentedFileDir, instrumentedFileName);
				System.out.println("Writing " + instrumentedFile);
				Writer output = new FileWriter(instrumentedFile);

				char[] contents = null;
				try {
					Document doc = new Document(fileContents);
					TextEdit edits = unit.rewrite(doc,null);
					edits.apply(doc);
					String sourceCode = doc.get();
					if (sourceCode != null) 
						contents = sourceCode.toCharArray(); 
				}
				catch (BadLocationException e) {
					throw new RuntimeException(e);
				}

				output.append(new String(contents));
				output.close();
				
				// Output original source file with .java.orig suffix.
				File origFile = new File(instrumentedFileDir, instrumentedFileName + ".orig");
				System.out.println("Writing " + origFile);
				output = new FileWriter(origFile);
				output.append(fileContents);
				output.close();

			} catch (IOException e) {
				System.err.println("Exception while instrumenting " + oneFile.getAbsolutePath());
				System.err.println(e.getMessage());
				e.printStackTrace();
				System.exit(1);
			}
		}
	}


	
	
	private static List<String> readJavaFileNames(List<String> fileListings) throws IOException {
		assert fileListings != null;
		List<String> ret = new ArrayList<String>();
		for (String oneListing : fileListings) {
			for (String oneLine : Files.readWhole(oneListing)) {
				oneLine = oneLine.trim();
				if (!oneLine.endsWith(".java")) {
					throw new RuntimeException("File " + oneListing + " contains a line not ending in .java: " + oneLine);
				}
				ret.add(oneLine);
			}
		}
		return ret;
	}




	private boolean preProcessClassOrEnumDeclaration() {
		// If this is a top-level class, reset state.
		if (classDepth == 0) {
			assert allMethodIndices == null;
			assert allMethodLineSpans == null;
			assert branchToLine == null;
			branchNumber = 0;
			methodDepth = 0;
			methodId = 0;
			allMethodIndices = new LinkedHashMap<String, Set<Integer>>();
			allMethodLineSpans = new LinkedHashMap<String, Pair<Integer,Integer>>();
			branchToLine = new ArrayList<Integer>();
		}
		classDepth++;
		return true;
	}

	private void postProcessClassOrEnumDeclaration(List bodyDeclarations) {
		// If this is a top-level class, output instrumentation declarations.
		if (classDepth == 1) {
			assert allMethodIndices != null;
			assert allMethodLineSpans != null;
			assert branchToLine != null;
			assert methodDepth == 0;
			// We must insert coverage-related fields before other declarations,
			// so that they are initialized before everything else (otherwise we
			// may get forward-reference error.
			bodyDeclarations.addAll(0, getCovIndicesMethod(allMethodIndices, branchToLine, branchNumber, allMethodLineSpans));
			allMethodIndices = null;
			allMethodLineSpans = null;
			branchToLine = null;
		}
		classDepth--;
	}
	
	@Override
	public boolean visit(TypeDeclaration type) {
		// Do nothing with interfaces.
		if (type.isInterface())
			return false;
		if (type.isLocalTypeDeclaration()) {
		  //System.out.println("@@@1" + type.toString());
		  return false;
		}
		if (type.isMemberTypeDeclaration()) {
		  //System.out.println("@@@2" + type.toString());
		  return false;
		}
		return preProcessClassOrEnumDeclaration();
	}

	@Override
	public void endVisit(TypeDeclaration type) {
		// Do nothing with interfaces.
    // TODO this will never happen because visit method returns false, right?
		if (type.isInterface())
			return;
    // TODO this will never happen because visit method returns false, right?
		if (type.isLocalTypeDeclaration())
		  return;
		if (type.isMemberTypeDeclaration()) 
		  return;
		postProcessClassOrEnumDeclaration(type.bodyDeclarations());
	}
	
	@Override
	public boolean visit(EnumDeclaration en) {
		return preProcessClassOrEnumDeclaration();
	}
	
	@Override
	public void endVisit(EnumDeclaration en) {
		postProcessClassOrEnumDeclaration(en.bodyDeclarations());
	}

	@Override
	public boolean visit(MethodDeclaration method) {

		if (methodDepth == 0) {
			assert oneMethodIndices == null;
			oneMethodIndices = new LinkedHashSet<Integer>();
			// add annotation @SimpleCovMethodId("X") where X is methodId.
			SingleMemberAnnotation anno = ast.newSingleMemberAnnotation();
			anno.setTypeName(ast.newName(MethodIdAnnotation));
			StringLiteral uniqueId = ast.newStringLiteral();
			uniqueId.setLiteralValue(Integer.toString(methodId));
			anno.setValue(uniqueId);
			method.modifiers().add(0, anno);
		}
		methodDepth++;
		return true;
	}

	@Override
	public void endVisit(MethodDeclaration method) {

		if (methodDepth == 1) {
			assert oneMethodIndices != null;
			try {
				allMethodIndices.put(Integer.toString(methodId), oneMethodIndices);
				int startLine = unit.getLineNumber(method.getStartPosition());
				int endLine = unit.getLineNumber(method.getStartPosition() + method.getLength());
				allMethodLineSpans.put(Integer.toString(methodId), new Pair<Integer,Integer>(startLine, endLine));
			} catch (Exception e ) {
				System.out.println(method.toString());
				throw new RuntimeException(e);
			}
			oneMethodIndices = null;
			methodId++;
		}
		methodDepth--;
	}

	/**
	 * Augments boolean expression e to also record whether it evaluates to
	 * true or false. Each expression is assigned a unique id.
	 * 
	 * If instrumentation==ARRAYS,
	 * e becomes ((e && ++branchTrue[13]!=0) || ++branchFalse[13]==0)
	 * which is equivalent to ((e && true) || false), because the array elements are
	 * initialized to zero and are only incremented.
	 * 
	 * Then:
	 * 
	 * If e==true,  ((true  && true) || false) == true
	 * If e==false, ((false && true) || false) == false
	 * 
	 * If instrumentation==PRINTOUT
	 * e becomes ((e && branchTrue(13)) || branchFalse(13))
	 * which works similar to ARRAYS but the branchTrue and branchFalse methods
	 * print out new coverage to System.out.
	 * 
	 */
	@Override
	public boolean visit(IfStatement ifst) {
		ifst.setExpression(coverageAugmentedExpr(ifst.getExpression(),
				unit.getLineNumber(ifst.getStartPosition()), false));
		return true;
	}

	@Override
	public boolean visit(ForStatement forst) {
		Expression exp = forst.getExpression();
		if (exp == null) {
			// Expression equivalent to true, so we'll never follow the other branch.
			// Thus no sense measuring branch coverage for this branch.
			return true;
		}
		forst.setExpression(coverageAugmentedExpr(exp, unit.getLineNumber(forst.getStartPosition()), false));
		return true;
	}
	
	@Override
	public boolean visit(WhileStatement whilest) {
	  Expression exp = whilest.getExpression();
	  whilest.setExpression(coverageAugmentedExpr(exp, unit.getLineNumber(whilest.getStartPosition()), false));
	  return true;
	}


	private static List<MethodDeclaration> branchMethods(String className, int totBranches) {

		StringBuilder code = new StringBuilder();
		code.append("public static void java.util.Set coverage = new java.util.LinkedHashSet();");
		code.append("public static boolean branchTrue(int index) {");
		code.append("  String cov = Integer.toString(index) + \"T\";");
		code.append("  if (coverage.add(cov))");
		// IF YOU MODIFY THE PRINTLN OUTPUT, UPDATE randoop.experiments.CountCoverage
		code.append("    System.out.println(\"COV:" + className  +
				":\" + coverage.size() + \":" + totBranches + ":\" + cov);");
		code.append("  return true;");
		code.append("}");
		code.append("public static boolean branchFalse(int index) {");
		code.append("  String cov = Integer.toString(index) + \"F\";");
		code.append("  if (coverage.add(cov))");
		// IF YOU MODIFY THE PRINTLN OUTPUT, UPDATE randoop.experiments.CountCoverage
		code.append("    System.out.println(\"COV:" + className  +
				":\" + coverage.size() + \":" + totBranches + ":\" + cov);");
		code.append("  return false;");
		code.append("}");

		List<BodyDeclaration> decls = ASTUtil.parseBodyDeclarations(code.toString(), ast);
		assert decls.size() == 2;
		List<MethodDeclaration> ret = new ArrayList<MethodDeclaration>();
		ret.add((MethodDeclaration) decls.get(0));
		ret.add((MethodDeclaration) decls.get(1));
		return ret;

	}

	private static List<BodyDeclaration> getCovIndicesMethod(Map<String,Set<Integer>> methodIndices,
			List<Integer> branchToLine, int totBranches, Map<String, Pair<Integer, Integer>> allMethodLineSpans) {
		
		assert totBranches == branchToLine.size() : "totBranches:" + totBranches + ",branchToLine.size()=" + branchToLine.size();
		StringBuilder code = new StringBuilder();
		
		code.append("public static final String " + sourceFileNameField + " = \"" + sourceFileName + "\";");
		code.append("public static final boolean " + isInstrumentedField + " = true;");
		
		code.append("public static int[] " + trueBranches + " = new int[" + totBranches + "];");
		code.append("public static int[] " + falseBranches + " = new int[" + totBranches + "];");
		code.append("public static java.util.Map " + methodIdToBranches +  " = new java.util.LinkedHashMap();");
		code.append("public static java.util.Map " + methodLineSpansField + " = new java.util.LinkedHashMap();");
		code.append("static {  ");
		for (Map.Entry<String,Set<Integer>> entry : methodIndices.entrySet()) {
			String methodSig = entry.getKey();
			code.append(methodIdToBranches + ".put(\"" + methodSig + "\", new int[]{");
			List<Integer> intList = new ArrayList<Integer>(entry.getValue());
			for (int i = 0 ; i < intList.size() ; i++) {
				if (i > 0) code.append(",");
				code.append(intList.get(i));
			}
			code.append("});");
		}
		for (Map.Entry<String,Pair<Integer,Integer>> entry : allMethodLineSpans.entrySet()) {
			String methodSig = entry.getKey();
			code.append(methodLineSpansField + ".put(\"" + methodSig + "\", new int[]{");
			code.append(entry.getValue().a + "," + entry.getValue().b + "});");
		}
		code.append("}");
		
		code.append("public static int " + branchLines + "[] = new int[]{");
		for (int i = 0 ; i < branchToLine.size() ; i++) {
			if (i > 0) code.append(",");
			code.append(branchToLine.get(i));
		}
		code.append("};");

		code.append("@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)");
		code.append("@java.lang.annotation.Target({java.lang.annotation.ElementType.METHOD,java.lang.annotation.ElementType.CONSTRUCTOR})");
		code.append("public static @interface " + MethodIdAnnotation + " {");
		code.append("String value();");
		code.append("};");
		
		List<BodyDeclaration> decls = ASTUtil.parseBodyDeclarations(code.toString(), ast);
		return decls;
	}


	private static Expression coverageAugmentedExpr(Expression exp, int lineNumber, boolean printout) {

		if (exp.toString().trim().equals("true") || exp.toString().trim().equals("false")) {
			return (Expression) ASTNode.copySubtree(ast, exp);
		}

		assert branchToLine.size() == branchNumber;
		branchToLine.add(lineNumber);
		if (oneMethodIndices != null) {
			oneMethodIndices.add(branchNumber);
		}

		StringBuilder code = new StringBuilder();
		if (!printout) {
			code.append("(((");
			code.append(exp.toString());
			code.append(") && ++");
			code.append(trueBranches);
			code.append("[");
			code.append(branchNumber);
			code.append("]!=0) || ++");
			code.append(falseBranches);
			code.append("[");
			code.append(branchNumber);
			code.append("]==0)");
		} else {
			code.append("(((");
			code.append(exp.toString());
			code.append(") && ");
			code.append("branchTrue(");
			code.append(branchNumber);
			code.append(")) || ");
			code.append("branchFalse(");
			code.append(branchNumber);
			code.append("))");
		}

		branchNumber++;
		return ASTUtil.parseExpression(code.toString(), ast);
	}
}
