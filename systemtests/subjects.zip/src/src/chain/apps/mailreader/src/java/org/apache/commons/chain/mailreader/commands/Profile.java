package org.apache.commons.chain.mailreader.commands;

/**
 * Individual settings for a user/client.
 */
public class Profile {
    public static String PROFILE_KEY = "profile";
}
